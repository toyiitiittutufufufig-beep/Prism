package com.prism.launcher;

import android.app.Activity;
import android.app.AlertDialog;
import android.appwidget.AppWidgetHost;
import android.appwidget.AppWidgetHostView;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProviderInfo;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.LauncherApps;
import android.net.Uri;
import android.os.Bundle;
import android.provider.AlarmClock;
import android.provider.Settings;
import android.util.SparseArray;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/** The home screen: pages of icons and widgets, a glass dock, the app drawer, gestures and drag & drop. */
public class LauncherActivity extends Activity implements GestureTracker.Host, DrawerView.Host {
    private static final int REQ_BIND = 1, REQ_CONFIG = 2;

    Prefs prefs;
    Model model;
    AppRepo repo;
    AppWidgetHost host;
    AppWidgetManager awm;
    FrameLayout root, overlay;
    BackdropView backdrop;
    ViewPager2 pager;
    PageIndicator indicator;
    GlassView dock;
    CellLayout dockGrid;
    DrawerView drawer;
    DragController drag;
    GestureTracker gestures;
    final SparseArray<CellLayout> cells = new SparseArray<CellLayout>();
    private final Map<Integer, PrismWidgetView> widgetViews = new HashMap<Integer, PrismWidgetView>();
    private PageAdapter adapter;
    int insetTop, insetBottom;
    private int stamp = -1;
    private float downRawX, downRawY;
    private View popup, sheet, sheetScrim, folderCard, folderScrim;
    private final Runnable badgesChanged = () -> refreshBadges();
    private boolean swallow;
    private int pendingId = -1;
    private AppWidgetProviderInfo pendingInfo;
    private int[] pendingSpan;

    private final Runnable appsChanged = () -> {
        model.prune(repo);
        refreshAll();
        drawer.refresh();
    };

    private static class PrismHost extends AppWidgetHost {
        PrismHost(Context c, int id) { super(c, id); }
        @Override protected AppWidgetHostView onCreateView(Context c, int id, AppWidgetProviderInfo info) {
            return new PrismWidgetView(c);
        }
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = Prefs.get(this);
        repo = AppRepo.get(this);
        model = new Model(this);
        awm = AppWidgetManager.getInstance(this);
        host = new PrismHost(this, 1024);

        root = new FrameLayout(this);
        setContentView(root);
        backdrop = new BackdropView(this);
        root.addView(backdrop, new FrameLayout.LayoutParams(-1, -1));

        pager = new ViewPager2(this);
        adapter = new PageAdapter();
        pager.setAdapter(adapter);
        pager.setOffscreenPageLimit(1);
        root.addView(pager, new FrameLayout.LayoutParams(-1, -1));

        indicator = new PageIndicator(this);
        root.addView(indicator, new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL));

        dock = new GlassView(this);
        dock.setRadiusDp(32);
        dock.setStrength(1.25f);
        dockGrid = new CellLayout(this);
        dock.addView(dockGrid, new FrameLayout.LayoutParams(-1, -1));
        root.addView(dock, new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM));

        drawer = new DrawerView(this, this);
        root.addView(drawer, new FrameLayout.LayoutParams(-1, -1));

        overlay = new FrameLayout(this);
        root.addView(overlay, new FrameLayout.LayoutParams(-1, -1));
        drag = new DragController(this, overlay);
        gestures = new GestureTracker(this, this);

        applySystemUi();
        root.setOnApplyWindowInsetsListener((v, ins) -> {
            insetTop = ins.getSystemWindowInsetTop();
            insetBottom = ins.getSystemWindowInsetBottom();
            applyLayout();
            return ins;
        });

        pager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override public void onPageScrolled(int pos, float off, int px) {
                float p = pos + off;
                indicator.setPosition(p);
                backdrop.setScroll(p);
            }
        });
        repo.addListener(appsChanged);
        PrismNotificationService.addListener(badgesChanged);
        rebuildAll();
    }

    @Override
    protected void onStart() {
        super.onStart();
        try { host.startListening(); } catch (Throwable ignored) { }
    }

    @Override
    protected void onStop() {
        try { host.stopListening(); } catch (Throwable ignored) { }
        super.onStop();
    }

    @Override
    protected void onResume() {
        super.onResume();
        applySystemUi();
        if (stamp != Prefs.stamp) rebuildAll();
    }

    @Override
    protected void onDestroy() {
        repo.removeListener(appsChanged);
        PrismNotificationService.removeListener(badgesChanged);
        super.onDestroy();
    }

    // ------------------------------------------------------------ layout

    private void rebuildAll() {
        stamp = Prefs.stamp;
        model.reload();
        if (prefs.b(Prefs.RESTORED, false)) {
            model.dropDeadWidgets();
            prefs.put(Prefs.RESTORED, false);
        }
        applySystemUi();
        setRequestedOrientation(prefs.b(Prefs.ROTATE, false) ? ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED : ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        model.ensureDefaults(repo);
        model.prune(repo);
        backdrop.reload();
        drawer.applyStyle();
        applyLayout();
        refreshAll();
    }

    void applyLayout() {
        int iconDp = prefs.iconDp();
        int dockH = Util.dp(this, iconDp + 30);
        int dockBottom = insetBottom + Util.dp(this, 12);
        FrameLayout.LayoutParams dl = (FrameLayout.LayoutParams) dock.getLayoutParams();
        dl.height = dockH;
        dl.leftMargin = dl.rightMargin = Util.dp(this, 14);
        dl.bottomMargin = dockBottom;
        dock.setStrength(prefs.b(Prefs.DOCK_GLASS, true) ? 1.25f : 0f);
        dock.setLayoutParams(dl);
        dockGrid.setCellPadding(Util.dp(this, 8), Util.dp(this, 4), Util.dp(this, 8), Util.dp(this, 4));

        FrameLayout.LayoutParams pl = (FrameLayout.LayoutParams) pager.getLayoutParams();
        pl.topMargin = insetTop + Util.dp(this, 6);
        pl.bottomMargin = dockBottom + dockH + Util.dp(this, 30);
        pager.setLayoutParams(pl);

        FrameLayout.LayoutParams il = (FrameLayout.LayoutParams) indicator.getLayoutParams();
        il.bottomMargin = dockBottom + dockH + Util.dp(this, 6);
        indicator.setLayoutParams(il);
        indicator.setAccent(Themes.get(prefs.theme()).accent);
        drawer.setInsets(insetTop, insetBottom);
    }

    void refreshAll() {
        int n = model.pageCount();
        indicator.setCount(n);
        adapter.notifyDataSetChanged();
        if (pager.getCurrentItem() >= n) pager.setCurrentItem(n - 1, false);
        bindDock();
    }

    void finishDrag() {
        refreshAll();
    }

    void addPage() {
        int n = model.pageCount();
        model.setPageCount(n + 1);
        refreshAll();
        pager.setCurrentItem(n, true);
    }

    // ------------------------------------------------------------ pages

    private class PageAdapter extends RecyclerView.Adapter<PageAdapter.VH> {
        class VH extends RecyclerView.ViewHolder {
            final CellLayout cell;
            VH(CellLayout c) { super(c); cell = c; }
        }

        @Override public VH onCreateViewHolder(ViewGroup p, int type) {
            CellLayout cl = new CellLayout(LauncherActivity.this);
            cl.setLayoutParams(new RecyclerView.LayoutParams(-1, -1));
            return new VH(cl);
        }

        @Override public void onBindViewHolder(VH h, int pos) {
            cells.put(pos, h.cell);
            bindPage(h.cell, pos);
        }

        @Override public void onViewRecycled(VH h) {
            int i = cells.indexOfValue(h.cell);
            if (i >= 0) cells.removeAt(i);
            h.cell.removeAllViews();
        }

        @Override public int getItemCount() { return model.pageCount(); }
    }

    private void bindPage(CellLayout cell, int page) {
        cell.setGrid(prefs.cols(), prefs.rows());
        cell.setCellPadding(Util.dp(this, 10), Util.dp(this, 4), Util.dp(this, 10), Util.dp(this, 4));
        cell.removeAllViews();
        for (ItemInfo it : model.page(page)) {
            View v = makeView(it);
            if (v != null) cell.addView(v, new CellLayout.LP(it.cx, it.cy, it.sx, it.sy));
        }
    }

    private void bindDock() {
        dockGrid.setGrid(prefs.dockCount(), 1);
        dockGrid.removeAllViews();
        for (ItemInfo it : model.dock()) {
            View v = makeView(it);
            if (v != null) dockGrid.addView(v, new CellLayout.LP(it.cx, 0, 1, 1));
        }
    }

    private View makeView(final ItemInfo it) {
        if (it.type == ItemInfo.APP) {
            final AppInfo ai = repo.find(it.comp);
            if (ai == null) return null;
            final AppIconView v = new AppIconView(this);
            v.bind(ai, it, prefs.labels() && !it.dock);
            v.setOnClickListener(x -> {
                if (!drag.isActive()) repo.launch(ai, v);
            });
            v.setOnLongClickListener(x -> {
                startDrag(it, ai, v, it.dock ? ShortcutPopup.DOCK : ShortcutPopup.HOME);
                return true;
            });
            return v;
        }
        if (it.type == ItemInfo.FOLDER) {
            final FolderIconView v = new FolderIconView(this);
            v.bind(it, !it.dock && prefs.labels());
            v.setOnClickListener(x -> {
                if (!drag.isActive()) openFolder(it);
            });
            v.setOnLongClickListener(x -> {
                startDrag(it, null, v, it.dock ? ShortcutPopup.DOCK : ShortcutPopup.HOME);
                return true;
            });
            return v;
        }
        if (it.type == ItemInfo.SEARCH) {
            final GlassView v = new GlassView(this);
            v.setRadiusDp(28);
            LinearLayout row = new LinearLayout(this);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(Util.dp(this, 20), 0, Util.dp(this, 20), 0);
            ImageView mag = new ImageView(this);
            mag.setImageResource(R.drawable.ic_search);
            mag.setAlpha(0.85f);
            row.addView(mag, new LinearLayout.LayoutParams(Util.dp(this, 22), Util.dp(this, 22)));
            TextView hint = new TextView(this);
            hint.setText(R.string.search_home);
            hint.setTextColor(0xCCFFFFFF);
            hint.setTextSize(16);
            LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-2, -2);
            hp.leftMargin = Util.dp(this, 12);
            row.addView(hint, hp);
            v.addView(row, new FrameLayout.LayoutParams(-1, -1));
            v.setOnClickListener(x -> openDrawer(true));
            v.setOnLongClickListener(x -> {
                startDrag(it, null, v, ShortcutPopup.HOME);
                return true;
            });
            return v;
        }
        if (it.type == ItemInfo.CLOCK) {
            final ClockWidgetView v = new ClockWidgetView(this);
            v.setOnClickListener(x -> {
                try { startActivity(new Intent(AlarmClock.ACTION_SHOW_ALARMS)); } catch (Throwable ignored) { }
            });
            v.setOnLongClickListener(x -> {
                startDrag(it, null, v, ShortcutPopup.HOME);
                return true;
            });
            return v;
        }
        // real widget
        PrismWidgetView wv = widgetViews.get(it.widgetId);
        if (wv == null) {
            AppWidgetProviderInfo info = awm.getAppWidgetInfo(it.widgetId);
            if (info == null) return null;
            AppWidgetHostView hv = host.createView(this, it.widgetId, info);
            if (!(hv instanceof PrismWidgetView)) return null;
            wv = (PrismWidgetView) hv;
            widgetViews.put(it.widgetId, wv);
        }
        if (wv.getParent() instanceof ViewGroup) ((ViewGroup) wv.getParent()).removeView(wv);
        wv.item = it;
        wv.listener = v -> startDrag(v.item, null, v, ShortcutPopup.HOME);
        return wv;
    }

    // ------------------------------------------------------------ touch

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        int a = ev.getActionMasked();
        if (a == MotionEvent.ACTION_DOWN) {
            downRawX = ev.getRawX();
            downRawY = ev.getRawY();
        }
        if (drag.isActive()) {
            if (drag.takeCancel()) {
                MotionEvent c = MotionEvent.obtain(ev);
                c.setAction(MotionEvent.ACTION_CANCEL);
                super.dispatchTouchEvent(c);
                c.recycle();
            }
            return drag.handle(ev);
        }
        if (swallow) {
            if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) swallow = false;
            return true;
        }
        if (popup != null && a == MotionEvent.ACTION_DOWN && !inside(popup, ev)) {
            dismissPopup();
            swallow = true;
            return true;
        }
        if (sheet != null || folderCard != null) return super.dispatchTouchEvent(ev);
        if (drawer.getVisibility() == View.VISIBLE && !gestures.claimed()) return super.dispatchTouchEvent(ev);
        if (popup == null && gestures.onTouch(ev)) return true;
        return super.dispatchTouchEvent(ev);
    }

    private boolean inside(View v, MotionEvent e) {
        int[] l = new int[2];
        v.getLocationOnScreen(l);
        return e.getRawX() >= l[0] && e.getRawX() <= l[0] + v.getWidth() && e.getRawY() >= l[1] && e.getRawY() <= l[1] + v.getHeight();
    }

    private View childAtRaw(CellLayout cl, float rx, float ry) {
        if (cl == null) return null;
        int[] l = new int[2];
        cl.getLocationOnScreen(l);
        return cl.childAt(rx - l[0], ry - l[1]);
    }

    // GestureTracker.Host
    @Override public boolean hitItem(float rx, float ry) {
        return childAtRaw(cells.get(pager.getCurrentItem()), rx, ry) != null || childAtRaw(dockGrid, rx, ry) != null;
    }

    @Override public boolean hitWidget(float rx, float ry) {
        return childAtRaw(cells.get(pager.getCurrentItem()), rx, ry) instanceof PrismWidgetView;
    }

    @Override public void dragDrawer(float dy) {
        drawer.setProgress(-dy / Math.max(1f, root.getHeight() * 0.85f));
    }

    @Override public void releaseDrawer(float vy) {
        boolean open = vy < -700 || (vy < 900 && drawer.progress() > 0.35f);
        drawer.animateTo(open, vy);
    }

    @Override public void action(String id) { Actions.run(this, id); }

    @Override public void longPressEmpty() {
        vibrate();
        showEditSheet();
    }

    @Override public void cancelChildren(MotionEvent ev) {
        MotionEvent c = MotionEvent.obtain(ev);
        c.setAction(MotionEvent.ACTION_CANCEL);
        super.dispatchTouchEvent(c);
        c.recycle();
    }

    // DrawerView.Host
    @Override public void onApp(AppInfo a, View v) {
        repo.launch(a, v);
        root.postDelayed(() -> drawer.animateTo(false, 0), 350);
    }

    @Override public void onAppLong(AppInfo a, View v, float rx, float ry) {
        ItemInfo tmp = new ItemInfo();
        tmp.type = ItemInfo.APP;
        tmp.comp = a.key;
        startDrag(tmp, a, v, ShortcutPopup.DRAWER);
    }

    @Override public void onProgress(float p) {
        float inv = 1f - p;
        pager.setAlpha(Math.max(0.25f, inv));
        pager.setScaleX(1f - 0.05f * p);
        pager.setScaleY(1f - 0.05f * p);
        dock.setAlpha(inv);
        dock.setTranslationY(p * Util.dp(this, 70));
        indicator.setAlpha(inv);
    }

    void openDrawer(boolean focusSearch) {
        drawer.animateTo(true, 0);
        if (focusSearch) drawer.focusSearch(true);
    }

    void closeDrawer(boolean fast) { drawer.animateTo(false, fast ? 3000 : 0); }

    // ------------------------------------------------------------ popup + sheet

    void vibrate() { root.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS); }

    void showPopup(View p, View anchor) {
        dismissPopup();
        popup = p;
        overlay.addView(p, new FrameLayout.LayoutParams(-2, -2));
        p.measure(View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED));
        int pw = p.getMeasuredWidth(), ph = p.getMeasuredHeight();
        int[] al = new int[2], ol = new int[2];
        anchor.getLocationOnScreen(al);
        overlay.getLocationOnScreen(ol);
        float x = al[0] - ol[0] + anchor.getWidth() / 2f - pw / 2f;
        x = Math.max(Util.dp(this, 12), Math.min(root.getWidth() - pw - Util.dp(this, 12), x));
        float y = al[1] - ol[1] - ph - Util.dp(this, 8);
        if (y < insetTop + Util.dp(this, 8)) y = al[1] - ol[1] + anchor.getHeight() + Util.dp(this, 8);
        p.setX(x);
        p.setY(y);
        p.setAlpha(0f);
        p.setPivotX(pw / 2f);
        p.setPivotY(y < al[1] - ol[1] ? ph : 0);
        p.setScaleX(0.88f);
        p.setScaleY(0.88f);
        p.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(140).start();
    }

    void dismissPopup() {
        if (popup != null) {
            overlay.removeView(popup);
            popup = null;
        }
    }

    void showSheet(View content) {
        closeSheet();
        sheetScrim = new View(this);
        sheetScrim.setBackgroundColor(0x66000000);
        sheetScrim.setAlpha(0f);
        sheetScrim.setOnClickListener(v -> closeSheet());
        overlay.addView(sheetScrim, new FrameLayout.LayoutParams(-1, -1));
        GlassView g = new GlassView(this);
        g.setRadiusDp(32);
        g.setTint(0x0B1020);
        g.setStrength(2.6f);
        g.addView(content, new FrameLayout.LayoutParams(-1, -2));
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM);
        lp.setMargins(Util.dp(this, 10), 0, Util.dp(this, 10), insetBottom + Util.dp(this, 10));
        overlay.addView(g, lp);
        sheet = g;
        g.setTranslationY(Util.dp(this, 500));
        g.animate().translationY(0).setDuration(260).start();
        sheetScrim.animate().alpha(1f).setDuration(200).start();
    }

    void closeSheet() {
        if (sheet != null) {
            overlay.removeView(sheet);
            sheet = null;
        }
        if (sheetScrim != null) {
            overlay.removeView(sheetScrim);
            sheetScrim = null;
        }
    }

    void showEditSheet() {
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(Util.dp(this, 16), Util.dp(this, 18), Util.dp(this, 16), Util.dp(this, 14));
        LinearLayout r1 = new LinearLayout(this), r2 = new LinearLayout(this), r3 = new LinearLayout(this);
        final boolean locked = prefs.b(Prefs.LOCK, false);
        r1.addView(tile(R.drawable.ic_widgets, R.string.widgets, () -> { closeSheet(); showSheet(WidgetPicker.build(this)); }));
        r1.addView(tile(R.drawable.ic_search, R.string.search_bar, () -> { closeSheet(); addSearchBar(); }));
        r2.addView(tile(R.drawable.ic_add, R.string.add_page, () -> { closeSheet(); addPage(); }));
        r2.addView(tile(R.drawable.ic_lock, locked ? R.string.unlock_layout : R.string.lock_layout, () -> {
            closeSheet();
            prefs.put(Prefs.LOCK, !locked);
            Toast.makeText(this, locked ? R.string.layout_unlocked : R.string.layout_locked, Toast.LENGTH_SHORT).show();
        }));
        r3.addView(tile(R.drawable.ic_brush, R.string.style_wallpaper, () -> { closeSheet(); startActivity(new Intent(this, SettingsActivity.class)); }));
        r3.addView(tile(R.drawable.ic_settings, R.string.settings, () -> { closeSheet(); startActivity(new Intent(this, SettingsActivity.class)); }));
        col.addView(r1, new LinearLayout.LayoutParams(-1, -2));
        col.addView(r2, new LinearLayout.LayoutParams(-1, -2));
        col.addView(r3, new LinearLayout.LayoutParams(-1, -2));
        showSheet(col);
    }

    private View tile(int icon, int label, final Runnable r) {
        GlassView g = new GlassView(this);
        g.setRadiusDp(22);
        g.setClickable(true);
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setGravity(Gravity.CENTER);
        c.setPadding(0, Util.dp(this, 18), 0, Util.dp(this, 16));
        ImageView iv = new ImageView(this);
        iv.setImageResource(icon);
        c.addView(iv, new LinearLayout.LayoutParams(Util.dp(this, 28), Util.dp(this, 28)));
        TextView t = new TextView(this);
        t.setText(label);
        t.setTextColor(0xFFFFFFFF);
        t.setTextSize(14);
        t.setGravity(Gravity.CENTER);
        t.setPadding(0, Util.dp(this, 8), 0, 0);
        c.addView(t);
        g.addView(c, new FrameLayout.LayoutParams(-1, -2));
        g.setOnClickListener(v -> r.run());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
        lp.setMargins(Util.dp(this, 6), Util.dp(this, 6), Util.dp(this, 6), Util.dp(this, 6));
        g.setLayoutParams(lp);
        return g;
    }

    // ------------------------------------------------------------ item actions

    void removeItem(ItemInfo it) {
        if (it.type == ItemInfo.WIDGET) {
            try { host.deleteAppWidgetId(it.widgetId); } catch (Throwable ignored) { }
            widgetViews.remove(it.widgetId);
        }
        model.remove(it);
        model.save();
        model.trimPages();
        refreshAll();
    }

    void openAppInfo(AppInfo a) {
        try {
            ((LauncherApps) getSystemService(Context.LAUNCHER_APPS_SERVICE)).startAppDetailsActivity(a.comp, a.user, null, null);
        } catch (Throwable e) {
            try {
                startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + a.comp.getPackageName())));
            } catch (Throwable ignored) { }
        }
    }

    void uninstall(AppInfo a) {
        try {
            startActivity(new Intent(Intent.ACTION_DELETE, Uri.parse("package:" + a.comp.getPackageName())));
        } catch (Throwable ignored) { }
    }

    void hideApp(AppInfo a) {
        Set<String> s = prefs.hidden();
        s.add(a.key);
        prefs.setHidden(s);
        stamp = Prefs.stamp;
        drawer.refresh();
    }

    void addToHome(AppInfo a) {
        int[] spot = null;
        int page = pager.getCurrentItem();
        for (int i = 0; i < model.pageCount() && spot == null; i++) {
            int p = (page + i) % model.pageCount();
            spot = model.findSpot(p, 1, 1);
            if (spot != null) page = p;
        }
        if (spot == null) {
            Toast.makeText(this, R.string.no_room, Toast.LENGTH_SHORT).show();
            return;
        }
        ItemInfo it = new ItemInfo();
        it.type = ItemInfo.APP;
        it.comp = a.key;
        it.page = page;
        it.cx = spot[0];
        it.cy = spot[1];
        model.add(it);
        model.save();
        closeDrawer(false);
        refreshAll();
        pager.setCurrentItem(page, false);
    }

    void resizeWidget(ItemInfo it, int dx, int dy) {
        int nsx = Math.max(1, Math.min(prefs.cols(), it.sx + dx));
        int nsy = Math.max(1, Math.min(prefs.rows(), it.sy + dy));
        if (model.isFree(false, it.page, it.cx, it.cy, nsx, nsy, it)) {
            it.sx = nsx;
            it.sy = nsy;
            model.save();
        } else {
            Toast.makeText(this, R.string.no_room, Toast.LENGTH_SHORT).show();
        }
        dismissPopup();
        refreshAll();
    }

    // ------------------------------------------------------------ widgets

    int[] cellsFor(AppWidgetProviderInfo p) {
        CellLayout cl = cells.get(pager.getCurrentItem());
        float cw = cl != null && cl.cellW() > 0 ? cl.cellW() : getResources().getDisplayMetrics().widthPixels / (float) prefs.cols();
        float ch = cl != null && cl.cellH() > 0 ? cl.cellH() : getResources().getDisplayMetrics().heightPixels / (float) (prefs.rows() + 2);
        int sx = Math.max(1, Math.min(prefs.cols(), (int) Math.ceil(p.minWidth / cw)));
        int sy = Math.max(1, Math.min(prefs.rows(), (int) Math.ceil(p.minHeight / ch)));
        return new int[] {sx, sy};
    }

    void addWidget(AppWidgetProviderInfo p) {
        closeSheet();
        pendingSpan = cellsFor(p);
        boolean room = false;
        for (int i = 0; i < model.pageCount() && !room; i++) room = model.findSpot(i, pendingSpan[0], pendingSpan[1]) != null;
        if (!room && model.pageCount() >= 6) {
            Toast.makeText(this, R.string.no_room, Toast.LENGTH_SHORT).show();
            return;
        }
        pendingInfo = p;
        pendingId = host.allocateAppWidgetId();
        boolean ok = false;
        try {
            ok = awm.bindAppWidgetIdIfAllowed(pendingId, p.provider);
        } catch (Throwable ignored) { }
        if (ok) {
            configureWidget();
        } else {
            Intent i = new Intent(AppWidgetManager.ACTION_APPWIDGET_BIND);
            i.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, pendingId);
            i.putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, p.provider);
            try {
                startActivityForResult(i, REQ_BIND);
            } catch (Throwable e) {
                finishWidget(false);
            }
        }
    }

    private void configureWidget() {
        if (pendingInfo != null && pendingInfo.configure != null) {
            try {
                host.startAppWidgetConfigureActivityForResult(this, pendingId, 0, REQ_CONFIG, null);
                return;
            } catch (Throwable ignored) { }
        }
        finishWidget(true);
    }

    private void finishWidget(boolean ok) {
        int id = pendingId;
        pendingId = -1;
        if (id < 0) return;
        if (ok && pendingSpan != null) {
            int page = pager.getCurrentItem();
            int[] spot = null;
            for (int i = 0; i < model.pageCount() && spot == null; i++) {
                int p = (page + i) % model.pageCount();
                spot = model.findSpot(p, pendingSpan[0], pendingSpan[1]);
                if (spot != null) page = p;
            }
            if (spot == null && model.pageCount() < 6) {
                model.setPageCount(model.pageCount() + 1);
                page = model.pageCount() - 1;
                spot = model.findSpot(page, pendingSpan[0], pendingSpan[1]);
            }
            if (spot != null) {
                ItemInfo it = new ItemInfo();
                it.type = ItemInfo.WIDGET;
                it.widgetId = id;
                it.page = page;
                it.cx = spot[0];
                it.cy = spot[1];
                it.sx = pendingSpan[0];
                it.sy = pendingSpan[1];
                model.add(it);
                model.save();
                refreshAll();
                pager.setCurrentItem(page, true);
                return;
            }
            Toast.makeText(this, R.string.no_room, Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, R.string.widget_failed, Toast.LENGTH_SHORT).show();
        }
        try { host.deleteAppWidgetId(id); } catch (Throwable ignored) { }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_BIND) {
            if (res == RESULT_OK) configureWidget(); else finishWidget(false);
        } else if (req == REQ_CONFIG) {
            finishWidget(res == RESULT_OK);
        }
    }

    // ------------------------------------------------------------ folders, search bar, rename, lock

    void applySystemUi() {
        int f = View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION;
        if (prefs.b(Prefs.HIDE_BAR, false)) f |= View.SYSTEM_UI_FLAG_FULLSCREEN;
        root.setSystemUiVisibility(f);
    }

    /** Long-press on an item: pick it up, unless the layout is locked (then just show the menu). */
    private void startDrag(ItemInfo it, AppInfo ai, View v, int source) {
        if (prefs.b(Prefs.LOCK, false)) {
            if (ai != null) showPopup(ShortcutPopup.forApp(this, ai, it, source), v);
            return;
        }
        drag.begin(it, ai, v, source, downRawX, downRawY);
    }

    private void refreshBadges() {
        for (int i = 0; i < cells.size(); i++) invalidateChildren(cells.valueAt(i));
        invalidateChildren(dockGrid);
        drawer.invalidateIcons();
    }

    private void invalidateChildren(ViewGroup g) {
        for (int i = 0; i < g.getChildCount(); i++) g.getChildAt(i).invalidate();
    }

    /** Dropping an app on another app (or on a folder) makes / fills a folder. */
    void mergeInto(ItemInfo target, ItemInfo dragged, AppInfo app, boolean fromDrawer) {
        if (target.type == ItemInfo.APP) {
            if (target.comp.equals(app.key)) return;
            target.type = ItemInfo.FOLDER;
            target.apps = new ArrayList<String>();
            target.apps.add(target.comp);
            target.apps.add(app.key);
            target.comp = "";
            target.title = getString(R.string.folder);
        } else if (target.type == ItemInfo.FOLDER) {
            if (!target.apps.contains(app.key)) target.apps.add(app.key);
        }
        if (!fromDrawer && dragged != null) model.remove(dragged);
        model.save();
    }

    void closeFolder() {
        if (folderCard != null) overlay.removeView(folderCard);
        if (folderScrim != null) overlay.removeView(folderScrim);
        folderCard = null;
        folderScrim = null;
    }

    void openFolder(final ItemInfo f) {
        closeFolder();
        folderScrim = new View(this);
        folderScrim.setBackgroundColor(0x77000000);
        folderScrim.setAlpha(0f);
        folderScrim.setOnClickListener(v -> closeFolder());
        overlay.addView(folderScrim, new FrameLayout.LayoutParams(-1, -1));

        GlassView g = new GlassView(this);
        g.setRadiusDp(34);
        g.setTint(0x0B1020);
        g.setStrength(2.6f);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(Util.dp(this, 14), Util.dp(this, 16), Util.dp(this, 14), Util.dp(this, 14));
        final TextView title = new TextView(this);
        title.setText(f.title.length() == 0 ? getString(R.string.folder) : f.title);
        title.setTextColor(0xFFFFFFFF);
        title.setTextSize(22);
        title.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, Util.dp(this, 4), 0, Util.dp(this, 12));
        title.setOnClickListener(v -> renameFolder(f, title));
        col.addView(title);

        int cols = 3, n = 0;
        LinearLayout row = null;
        for (String key : new ArrayList<String>(f.apps)) {
            final AppInfo ai = repo.find(key);
            if (ai == null) continue;
            if (n % cols == 0) {
                row = new LinearLayout(this);
                col.addView(row, new LinearLayout.LayoutParams(-1, -2));
            }
            final AppIconView v = new AppIconView(this);
            v.bind(ai, null, true);
            row.addView(v, new LinearLayout.LayoutParams(0, Util.dp(this, 104), 1f));
            v.setOnClickListener(x -> {
                closeFolder();
                repo.launch(ai, v);
            });
            v.setOnLongClickListener(x -> {
                folderAppMenu(f, ai);
                return true;
            });
            n++;
        }
        while (row != null && n % cols != 0) {
            row.addView(new View(this), new LinearLayout.LayoutParams(0, Util.dp(this, 104), 1f));
            n++;
        }
        g.addView(col, new FrameLayout.LayoutParams(-1, -2));
        overlay.addView(g, new FrameLayout.LayoutParams(Math.round(root.getWidth() * 0.88f), -2, Gravity.CENTER));
        folderCard = g;
        g.setScaleX(0.8f);
        g.setScaleY(0.8f);
        g.setAlpha(0f);
        g.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(200).start();
        folderScrim.animate().alpha(1f).setDuration(200).start();
    }

    private AlertDialog.Builder dialog() {
        return new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert);
    }

    private void renameFolder(final ItemInfo f, final TextView titleView) {
        final EditText e = new EditText(this);
        e.setText(f.title);
        e.setSingleLine(true);
        e.setSelectAllOnFocus(true);
        dialog().setTitle(R.string.rename).setView(e).setPositiveButton(R.string.done, (d, w) -> {
            f.title = e.getText().toString().trim();
            model.save();
            titleView.setText(f.title.length() == 0 ? getString(R.string.folder) : f.title);
            refreshAll();
        }).setNegativeButton(R.string.cancel, null).show();
    }

    private void folderAppMenu(final ItemInfo f, final AppInfo ai) {
        String[] items = {getString(R.string.move_out), getString(R.string.app_info)};
        dialog().setItems(items, (d, which) -> {
            if (which == 0) moveOutOfFolder(f, ai); else openAppInfo(ai);
        }).show();
    }

    private void moveOutOfFolder(ItemInfo f, AppInfo ai) {
        int page = pager.getCurrentItem();
        int[] spot = null;
        for (int i = 0; i < model.pageCount() && spot == null; i++) {
            int p = (page + i) % model.pageCount();
            spot = model.findSpot(p, 1, 1);
            if (spot != null) page = p;
        }
        if (spot == null) {
            Toast.makeText(this, R.string.no_room, Toast.LENGTH_SHORT).show();
            return;
        }
        f.apps.remove(ai.key);
        ItemInfo it = new ItemInfo();
        it.type = ItemInfo.APP;
        it.comp = ai.key;
        it.page = page;
        it.cx = spot[0];
        it.cy = spot[1];
        model.add(it);
        if (f.apps.size() <= 1) {
            if (f.apps.size() == 1) {
                f.type = ItemInfo.APP;
                f.comp = f.apps.get(0);
                f.apps = new ArrayList<String>();
            } else {
                model.remove(f);
            }
        }
        model.save();
        closeFolder();
        refreshAll();
    }

    void renameApp(final AppInfo a) {
        final EditText e = new EditText(this);
        e.setText(a.label);
        e.setSingleLine(true);
        e.setSelectAllOnFocus(true);
        dialog().setTitle(R.string.rename).setView(e)
                .setPositiveButton(R.string.done, (d, w) -> repo.setCustomLabel(a.key, e.getText().toString()))
                .setNeutralButton(R.string.reset_name, (d, w) -> repo.setCustomLabel(a.key, ""))
                .setNegativeButton(R.string.cancel, null).show();
    }

    private void addSearchBar() {
        int cols = prefs.cols();
        int page = pager.getCurrentItem();
        int[] spot = null;
        for (int i = 0; i < model.pageCount() && spot == null; i++) {
            int p = (page + i) % model.pageCount();
            spot = model.findSpot(p, cols, 1);
            if (spot != null) page = p;
        }
        if (spot == null) {
            Toast.makeText(this, R.string.no_room, Toast.LENGTH_SHORT).show();
            return;
        }
        ItemInfo it = new ItemInfo();
        it.type = ItemInfo.SEARCH;
        it.page = page;
        it.cx = spot[0];
        it.cy = spot[1];
        it.sx = cols;
        model.add(it);
        model.save();
        refreshAll();
        pager.setCurrentItem(page, true);
    }

    // ------------------------------------------------------------ system buttons

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        if (drag.isActive()) return;
        dismissPopup();
        closeSheet();
        closeFolder();
        if (drawer.getVisibility() == View.VISIBLE) drawer.animateTo(false, 0);
        else if (pager.getCurrentItem() != 0) pager.setCurrentItem(0, true);
    }

    @Override
    public void onBackPressed() {
        if (popup != null) dismissPopup();
        else if (folderCard != null) closeFolder();
        else if (sheet != null) closeSheet();
        else if (drawer.getVisibility() == View.VISIBLE) drawer.animateTo(false, 0);
        else if (pager.getCurrentItem() != 0) pager.setCurrentItem(0, true);
    }
}
