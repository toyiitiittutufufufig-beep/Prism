package com.prism.launcher;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Outline;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewOutlineProvider;
import android.widget.FrameLayout;

/**
 * "Liquid glass" panel: a translucent frosted fill, a soft sheen on the upper half and a bright specular
 * rim that fades around the edge. Put it over a blurred backdrop and the art shines through.
 */
public class GlassView extends FrameLayout {
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint sheen = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint rim = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint rim2 = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private final RectF inner = new RectF();
    private final Path clip = new Path();
    private float radius;
    private float strength = 1f;
    private float r;
    private int tint = 0xFFFFFF;

    public GlassView(Context c) { this(c, null); }

    public GlassView(Context c, AttributeSet a) {
        super(c, a);
        radius = Util.dp(c, 24);
        if (a != null) {
            TypedArray t = c.obtainStyledAttributes(a, R.styleable.GlassView);
            radius = t.getDimension(R.styleable.GlassView_glassRadius, radius);
            strength = t.getFloat(R.styleable.GlassView_glassStrength, 1f);
            tint = t.getColor(R.styleable.GlassView_glassTint, 0xFFFFFFFF) & 0xFFFFFF;
            t.recycle();
        }
        setWillNotDraw(false);
        rim.setStyle(Paint.Style.STROKE);
        rim.setStrokeWidth(Util.dp(c, 1.2f));
        rim2.setStyle(Paint.Style.STROKE);
        rim2.setStrokeWidth(Util.dp(c, 3f));
        setOutlineProvider(new ViewOutlineProvider() {
            @Override public void getOutline(View v, Outline o) {
                o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), r);
            }
        });
        setClipToOutline(true);
    }

    public void setRadiusDp(float dp) {
        radius = Util.dp(getContext(), dp);
        rebuild(getWidth(), getHeight());
        invalidateOutline();
        invalidate();
    }

    private int a(int alpha) {
        int v = Math.max(0, Math.min(255, Math.round(alpha * strength)));
        return (v << 24) | tint;
    }

    /** Edge light stays white whatever the tint is. */
    private int w(int alpha) {
        int v = Math.max(0, Math.min(255, Math.round(alpha * Math.min(strength, 1.3f))));
        return (v << 24) | 0xFFFFFF;
    }

    public void setStrength(float s) {
        strength = s;
        rebuild(getWidth(), getHeight());
        invalidate();
    }

    public void setTint(int color) {
        tint = color & 0xFFFFFF;
        rebuild(getWidth(), getHeight());
        invalidate();
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        rebuild(w, h);
    }

    private void rebuild(int w, int h) {
        if (w <= 0 || h <= 0) return;
        r = Math.min(radius, Math.min(w, h) / 2f);
        rect.set(0, 0, w, h);
        float half = rim.getStrokeWidth() / 2f;
        inner.set(half, half, w - half, h - half);
        clip.reset();
        clip.addRoundRect(rect, r, r, Path.Direction.CW);
        fill.setShader(new LinearGradient(0, 0, 0, h,
                new int[] {a(0x42), a(0x20), a(0x2C)}, new float[] {0f, 0.55f, 1f}, Shader.TileMode.CLAMP));
        sheen.setShader(new LinearGradient(0, 0, 0, h * 0.6f,
                new int[] {w(0x44), w(0x00)}, null, Shader.TileMode.CLAMP));
        rim.setShader(new LinearGradient(0, 0, w, h,
                new int[] {w(0xE0), w(0x14), w(0x10), w(0x90)}, new float[] {0f, 0.38f, 0.62f, 1f}, Shader.TileMode.CLAMP));
        rim2.setShader(new LinearGradient(0, 0, w, h,
                new int[] {w(0x30), w(0x00), w(0x00), w(0x22)}, new float[] {0f, 0.4f, 0.6f, 1f}, Shader.TileMode.CLAMP));
        invalidateOutline();
    }

    @Override
    protected void onDraw(Canvas c) {
        if (rect.isEmpty()) return;
        c.drawRoundRect(rect, r, r, fill);
        c.save();
        c.clipPath(clip);
        c.drawRect(0, 0, rect.right, rect.bottom * 0.6f, sheen);
        c.drawRoundRect(inner, r, r, rim2);   // soft inner glow along the edge
        c.restore();
        c.drawRoundRect(inner, Math.max(0, r - rim.getStrokeWidth() / 2f), Math.max(0, r - rim.getStrokeWidth() / 2f), rim);
    }
}
