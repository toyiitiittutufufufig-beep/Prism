package com.prism.launcher;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Shader;
import android.graphics.drawable.AdaptiveIconDrawable;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.LruCache;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Renders app icons in the chosen shape / glass style (or from an icon pack) and caches them. */
public class IconCache {
    public interface Cb { void done(Bitmap b); }

    private static final ExecutorService POOL = Executors.newFixedThreadPool(2);
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static final LruCache<String, Bitmap> CACHE = new LruCache<String, Bitmap>(32 * 1024 * 1024) {
        @Override protected int sizeOf(String k, Bitmap b) { return b.getByteCount(); }
    };
    private static String packName = null;
    private static IconPack pack = null;

    private static String key(Prefs p, AppInfo a, int px) {
        return a.key + "|" + px + "|" + p.shape() + "|" + p.glass() + "|" + p.pack() + "|" + p.b(Prefs.THEMED, false) + "|" + p.theme();
    }

    public static void load(final Context c, final AppInfo a, final int px, final Cb cb) {
        final Prefs p = Prefs.get(c);
        final String k = key(p, a, px);
        Bitmap hit = CACHE.get(k);
        if (hit != null) {
            cb.done(hit);
            return;
        }
        POOL.execute(() -> {
            Bitmap b;
            try {
                b = render(c.getApplicationContext(), p, a, px);
            } catch (Throwable e) {
                b = null;
            }
            final Bitmap r = b;
            if (r != null) CACHE.put(k, r);
            MAIN.post(() -> cb.done(r));
        });
    }

    private static synchronized IconPack currentPack(Context c, Prefs p) {
        String want = p.pack();
        if (want.length() == 0) {
            packName = "";
            pack = null;
            return null;
        }
        if (!want.equals(packName)) {
            packName = want;
            pack = IconPack.load(c, want);
        }
        return pack;
    }

    private static Bitmap render(Context c, Prefs p, AppInfo a, int px) {
        Bitmap b = renderRaw(c, p, a, px);
        if (a.work && b != null) {
            try {   // the little briefcase on work apps
                Drawable bd = c.getPackageManager().getUserBadgedIcon(new BitmapDrawable(c.getResources(), b), a.user);
                return Util.toBitmap(bd, px, px);
            } catch (Throwable ignored) { }
        }
        return b;
    }

    private static Bitmap renderRaw(Context c, Prefs p, AppInfo a, int px) {
        IconPack ip = currentPack(c, p);
        if (ip != null) {
            Drawable pd = ip.get(a.comp);
            if (pd != null) return Util.toBitmap(pd, px, px);
        }
        Drawable d = null;
        try {
            d = a.info.getIcon(c.getResources().getDisplayMetrics().densityDpi);
        } catch (Throwable ignored) { }
        if (d == null) d = c.getPackageManager().getDefaultActivityIcon();
        if (ip != null && ip.hasBack()) return ip.compose(d, px);
        return compose(d, px, p.shape(), p.glass(), p.b(Prefs.THEMED, false), Themes.get(p.theme()).accent);
    }

    private static int lighten(int c) {
        float k = 0.7f;
        return Color.rgb(Math.round(Color.red(c) + (255 - Color.red(c)) * k), Math.round(Color.green(c) + (255 - Color.green(c)) * k),
                Math.round(Color.blue(c) + (255 - Color.blue(c)) * k));
    }

    private static Bitmap compose(Drawable d, int px, int shape, boolean glass, boolean themed, int accent) {
        boolean adaptive = d instanceof AdaptiveIconDrawable;
        if (shape == ShapeUtil.SYSTEM) return Util.toBitmap(d, px, px);

        Bitmap out = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(out);
        Path clip = ShapeUtil.path(shape, px);
        Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);

        if (adaptive) {
            AdaptiveIconDrawable ad = (AdaptiveIconDrawable) d;
            int full = Math.round(px * 108f / 72f);
            int off = (full - px) / 2;
            Drawable mono = null;
            if (themed && Build.VERSION.SDK_INT >= 33) mono = ad.getMonochrome();
            c.save();
            c.clipPath(clip);
            if (mono != null) {
                // themed icon: the app's one-color glyph in the theme's color on a tinted glass tile
                fill.setShader(new LinearGradient(0, 0, 0, px, Util.withAlpha(accent, 0x99), Util.withAlpha(accent, 0x55), Shader.TileMode.CLAMP));
                c.drawRect(0, 0, px, px, fill);
                fill.setShader(null);
                mono = mono.mutate();
                mono.setTint(lighten(accent));
                mono.setBounds(-off, -off, px + off, px + off);
                mono.draw(c);
            } else {
                Drawable bg = ad.getBackground(), fg = ad.getForeground();
                if (bg != null) {
                    bg.setBounds(-off, -off, px + off, px + off);
                    bg.draw(c);
                }
                if (fg != null) {
                    fg.setBounds(-off, -off, px + off, px + off);
                    fg.draw(c);
                }
            }
            c.restore();
        } else {
            // old-style icon: sit it on a translucent tile so everything matches
            c.save();
            c.clipPath(clip);
            fill.setShader(new LinearGradient(0, 0, 0, px, 0x66FFFFFF, 0x30FFFFFF, Shader.TileMode.CLAMP));
            c.drawRect(0, 0, px, px, fill);
            fill.setShader(null);
            c.restore();
            int in = Math.round(px * 0.68f), off = (px - in) / 2;
            d.setBounds(off, off, off + in, off + in);
            d.draw(c);
        }

        if (glass) {
            Paint sheen = new Paint(Paint.ANTI_ALIAS_FLAG);
            sheen.setShader(new LinearGradient(0, 0, 0, px * 0.6f, 0x55FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP));
            c.save();
            c.clipPath(clip);
            c.drawRect(0, 0, px, px * 0.6f, sheen);
            c.restore();
            Paint rim = new Paint(Paint.ANTI_ALIAS_FLAG);
            rim.setStyle(Paint.Style.STROKE);
            rim.setStrokeWidth(Math.max(1.5f, px * 0.02f));
            rim.setShader(new LinearGradient(0, 0, px, px, 0xCCFFFFFF, 0x22FFFFFF, Shader.TileMode.CLAMP));
            c.drawPath(clip, rim);
        }
        return out;
    }
}
