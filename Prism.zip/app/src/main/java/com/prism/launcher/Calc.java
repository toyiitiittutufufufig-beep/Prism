package com.prism.launcher;

import java.math.BigDecimal;
import java.math.MathContext;

/** Type "12*(3+4)" in the drawer search and get the answer. */
public class Calc {
    /** The result as text, or null when the query isn't a calculation. */
    public static String format(String q) {
        if (q == null) return null;
        String t = q.trim();
        if (!t.matches("[0-9+\\-*/().^%\\s\u00d7\u00f7xX,]+")) return null;
        t = t.replace('\u00d7', '*').replace('\u00f7', '/').replace('x', '*').replace('X', '*').replace(',', '.');
        if (!t.matches(".*[0-9)]\\s*[+*/^%-].*")) return null;   // a lone number is not a calculation
        try {
            P p = new P(t);
            double v = p.expr();
            p.end();
            if (Double.isNaN(v) || Double.isInfinite(v)) return null;
            if (v == Math.rint(v) && Math.abs(v) < 1e15) return String.valueOf((long) v);
            return new BigDecimal(v).round(new MathContext(10)).stripTrailingZeros().toPlainString();
        } catch (Throwable e) {
            return null;
        }
    }

    private static class P {
        final String s;
        int i = 0;

        P(String s) { this.s = s.replace(" ", ""); }

        void end() { if (i != s.length()) throw new IllegalStateException(); }

        boolean eat(char c) {
            if (i < s.length() && s.charAt(i) == c) {
                i++;
                return true;
            }
            return false;
        }

        double expr() {
            double v = term();
            while (true) {
                if (eat('+')) v += term();
                else if (eat('-')) v -= term();
                else return v;
            }
        }

        double term() {
            double v = power();
            while (true) {
                if (eat('*')) v *= power();
                else if (eat('/')) v /= power();
                else if (eat('%')) v %= power();
                else return v;
            }
        }

        double power() {
            double b = unary();
            if (eat('^')) return Math.pow(b, power());
            return b;
        }

        double unary() {
            if (eat('-')) return -unary();
            if (eat('+')) return unary();
            if (eat('(')) {
                double v = expr();
                if (!eat(')')) throw new IllegalStateException();
                return v;
            }
            int st = i;
            while (i < s.length() && (Character.isDigit(s.charAt(i)) || s.charAt(i) == '.')) i++;
            if (st == i) throw new IllegalStateException();
            return Double.parseDouble(s.substring(st, i));
        }
    }
}
