package com.prism.launcher;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.RenderEffect;
import android.graphics.Shader;
import android.os.Build;
import android.os.SystemClock;
import android.view.View;

/** The home screen background: an animated scene that drifts a little as you swipe between pages. */
public class BackdropView extends View {
    private int style;
    private Themes.T th = Themes.get(0);
    private Bitmap photo;
    private float scroll;
    private int dim;

    public BackdropView(Context c) {
        super(c);
        reload();
    }

    public void reload() {
        Prefs p = Prefs.get(getContext());
        style = p.bg();
        dim = p.i(Prefs.DIM, 0);
        th = Themes.get(p.theme());
        photo = style == Scenes.PHOTO ? Scenes.loadPhoto(getContext()) : null;
        invalidate();
    }

    public void setScroll(float s) {
        scroll = s;
        if (!Scenes.animated(style)) invalidate();
    }

    /** Blurred copy (Android 12+) used behind the app drawer. */
    public void setBlurred(boolean on) {
        if (Build.VERSION.SDK_INT >= 31) {
            setRenderEffect(on ? RenderEffect.createBlurEffect(60f, 60f, Shader.TileMode.CLAMP) : null);
        }
    }

    @Override
    protected void onDraw(Canvas c) {
        Scenes.draw(c, getWidth(), getHeight(), SystemClock.uptimeMillis(), style, th, scroll, photo);
        if (dim > 0) c.drawColor((Math.min(70, dim) * 255 / 100) << 24);
        if (Scenes.animated(style)) postInvalidateDelayed(24);
    }
}
