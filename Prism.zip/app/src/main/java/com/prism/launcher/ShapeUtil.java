package com.prism.launcher;

import android.graphics.Path;
import android.graphics.RectF;

public class ShapeUtil {
    public static final int SYSTEM = 0, SQUIRCLE = 1, CIRCLE = 2, ROUNDED = 3, TEARDROP = 4, SQUARE = 5;
    public static final String[] NAMES = {"System", "Squircle", "Circle", "Rounded square", "Teardrop", "Square"};

    public static Path path(int shape, float s) {
        Path p = new Path();
        RectF r = new RectF(0, 0, s, s);
        switch (shape) {
            case CIRCLE:
                p.addCircle(s / 2f, s / 2f, s / 2f, Path.Direction.CW);
                break;
            case ROUNDED:
                p.addRoundRect(r, s * 0.26f, s * 0.26f, Path.Direction.CW);
                break;
            case SQUARE:
                p.addRoundRect(r, s * 0.08f, s * 0.08f, Path.Direction.CW);
                break;
            case TEARDROP: {
                float big = s * 0.5f, small = s * 0.12f;
                p.addRoundRect(r, new float[] {big, big, small, small, big, big, big, big}, Path.Direction.CW);
                break;
            }
            default: {   // squircle (superellipse)
                int n = 72;
                double e = 2.0 / 4.6;
                for (int k = 0; k <= n; k++) {
                    double t = 2 * Math.PI * k / n;
                    double c = Math.cos(t), sn = Math.sin(t);
                    float x = (float) (s / 2f + (s / 2f) * Math.signum(c) * Math.pow(Math.abs(c), e));
                    float y = (float) (s / 2f + (s / 2f) * Math.signum(sn) * Math.pow(Math.abs(sn), e));
                    if (k == 0) p.moveTo(x, y); else p.lineTo(x, y);
                }
                p.close();
            }
        }
        return p;
    }
}
