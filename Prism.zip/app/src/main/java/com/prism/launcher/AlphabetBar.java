package com.prism.launcher;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.MotionEvent;
import android.view.View;

/** A-Z strip on the edge of the app drawer: slide a finger along it to jump. */
public class AlphabetBar extends View {
    public interface Cb { void onLetter(char c, boolean active); }

    private static final char[] L = "#ABCDEFGHIJKLMNOPQRSTUVWXYZ".toCharArray();
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private Cb cb;
    private int accent = 0xFFFFFFFF;
    private int active = -1;

    public AlphabetBar(Context c) {
        super(c);
        p.setTextAlign(Paint.Align.CENTER);
        p.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
    }

    public void setCb(Cb c) { cb = c; }
    public void setAccent(int c) { accent = c; invalidate(); }

    @Override
    protected void onDraw(Canvas c) {
        float step = getHeight() / (float) L.length;
        p.setTextSize(Math.min(11f * getResources().getDisplayMetrics().scaledDensity, step * 0.8f));
        for (int i = 0; i < L.length; i++) {
            p.setColor(i == active ? accent : 0xAAFFFFFF);
            c.drawText(String.valueOf(L[i]), getWidth() / 2f, step * i + step * 0.5f + p.getTextSize() * 0.35f, p);
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        int a = e.getActionMasked();
        if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
            active = -1;
            invalidate();
            if (cb != null) cb.onLetter(' ', false);
            return true;
        }
        getParent().requestDisallowInterceptTouchEvent(true);
        int idx = Math.max(0, Math.min(L.length - 1, (int) (e.getY() / (getHeight() / (float) L.length))));
        if (idx != active) {
            active = idx;
            invalidate();
            performHapticFeedback(android.view.HapticFeedbackConstants.CLOCK_TICK);
            if (cb != null) cb.onLetter(L[idx], true);
        }
        return true;
    }
}
