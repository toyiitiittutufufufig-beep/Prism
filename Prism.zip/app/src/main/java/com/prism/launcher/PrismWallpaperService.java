package com.prism.launcher;

import android.graphics.Canvas;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.service.wallpaper.WallpaperService;
import android.view.SurfaceHolder;

/** The launcher's animated backgrounds as a real system live wallpaper. */
public class PrismWallpaperService extends WallpaperService {
    @Override
    public Engine onCreateEngine() {
        return new E();
    }

    private class E extends Engine {
        private final Handler h = new Handler(Looper.getMainLooper());
        private boolean visible;
        private int w, hh;
        private float scroll;
        private final Runnable frame = new Runnable() {
            @Override public void run() {
                draw();
                if (visible) h.postDelayed(this, 33);
            }
        };

        @Override
        public void onSurfaceChanged(SurfaceHolder holder, int format, int width, int height) {
            super.onSurfaceChanged(holder, format, width, height);
            w = width;
            hh = height;
            draw();
        }

        @Override
        public void onVisibilityChanged(boolean v) {
            visible = v;
            h.removeCallbacks(frame);
            if (v) h.post(frame);
        }

        @Override
        public void onOffsetsChanged(float xOffset, float yOffset, float xStep, float yStep, int xPix, int yPix) {
            scroll = xOffset * 3f;
        }

        @Override
        public void onSurfaceDestroyed(SurfaceHolder holder) {
            visible = false;
            h.removeCallbacks(frame);
            super.onSurfaceDestroyed(holder);
        }

        private void draw() {
            SurfaceHolder sh = getSurfaceHolder();
            Canvas c = null;
            try {
                c = sh.lockHardwareCanvas();
                if (c == null) return;
                Prefs p = Prefs.get(PrismWallpaperService.this);
                int style = p.bg();
                if (style == Scenes.SYSTEM) style = Scenes.AURORA;
                Scenes.draw(c, w, hh, SystemClock.uptimeMillis(), style, Themes.get(p.theme()), scroll,
                        style == Scenes.PHOTO ? Scenes.loadPhoto(PrismWallpaperService.this) : null);
            } catch (Throwable ignored) {
            } finally {
                if (c != null) {
                    try { sh.unlockCanvasAndPost(c); } catch (Throwable ignored) { }
                }
            }
        }
    }
}
