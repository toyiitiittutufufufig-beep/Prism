package com.prism.launcher;

import android.appwidget.AppWidgetHostView;
import android.content.Context;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.ViewConfiguration;

/** Widget host view that reports a long-press (so widgets can be picked up and dragged). */
public class PrismWidgetView extends AppWidgetHostView {
    public interface LongPress { void onLongPress(PrismWidgetView v); }

    public LongPress listener;
    public ItemInfo item;
    private boolean fired;
    private float downX, downY;
    private final Runnable press = () -> {
        fired = true;
        performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
        if (listener != null) listener.onLongPress(PrismWidgetView.this);
    };

    public PrismWidgetView(Context c) { super(c); }

    @Override
    public boolean onInterceptTouchEvent(MotionEvent ev) {
        switch (ev.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                fired = false;
                downX = ev.getX();
                downY = ev.getY();
                postDelayed(press, ViewConfiguration.getLongPressTimeout());
                break;
            case MotionEvent.ACTION_MOVE: {
                float s = ViewConfiguration.get(getContext()).getScaledTouchSlop();
                if (Math.abs(ev.getX() - downX) > s || Math.abs(ev.getY() - downY) > s) removeCallbacks(press);
                break;
            }
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                removeCallbacks(press);
                break;
        }
        return fired;
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        float d = getResources().getDisplayMetrics().density;
        int dw = Math.round(w / d), dh = Math.round(h / d);
        updateAppWidgetSize(null, dw, dh, dw, dh);
    }
}
