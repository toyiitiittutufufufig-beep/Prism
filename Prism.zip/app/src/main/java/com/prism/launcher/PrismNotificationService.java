package com.prism.launcher;

import android.app.Notification;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;

/** Counts unread notifications per app so icons can show a badge. Reads only the app + count, nothing else. */
public class PrismNotificationService extends NotificationListenerService {
    private static final Map<String, Integer> COUNTS = new HashMap<String, Integer>();
    private static final CopyOnWriteArrayList<Runnable> LISTENERS = new CopyOnWriteArrayList<Runnable>();
    private static boolean connected;
    private static PrismNotificationService inst;

    public static PrismNotificationService get() { return inst; }

    public static int count(String pkg) {
        Integer n = COUNTS.get(pkg);
        return n == null ? 0 : n;
    }

    public static boolean connected() { return connected; }
    public static void addListener(Runnable r) { if (!LISTENERS.contains(r)) LISTENERS.add(r); }
    public static void removeListener(Runnable r) { LISTENERS.remove(r); }

    private static void fire() {
        for (Runnable r : LISTENERS) r.run();
    }

    @Override
    public void onListenerConnected() {
        inst = this;
        connected = true;
        recompute();
        Island.ensure(this);
    }

    @Override
    public void onListenerDisconnected() {
        inst = null;
        connected = false;
        COUNTS.clear();
        fire();
        Island.ensure(getApplicationContext());
    }

    @Override public void onNotificationPosted(StatusBarNotification sbn) {
        recompute();
        maybeShow(sbn);
    }

    @Override public void onNotificationRemoved(StatusBarNotification sbn) {
        recompute();
        Island.forget(sbn.getKey());
    }

    /** Pop it out of the island, unless it is silent, ongoing, ours, or the screen is off. */
    private void maybeShow(StatusBarNotification s) {
        try {
            if (!Prefs.get(this).b(Prefs.ISLAND, false)) return;
            if (s.getPackageName().equals(getPackageName())) return;
            Notification n = s.getNotification();
            if (s.isOngoing() || (n.flags & Notification.FLAG_GROUP_SUMMARY) != 0) return;
            android.os.PowerManager pm = (android.os.PowerManager) getSystemService(POWER_SERVICE);
            if (pm != null && !pm.isInteractive()) return;
            Ranking r = new Ranking();
            if (getCurrentRanking().getRanking(s.getKey(), r) && r.getImportance() < android.app.NotificationManager.IMPORTANCE_DEFAULT) return;
            Island.show(s);
        } catch (Throwable ignored) { }
    }

    private void recompute() {
        Map<String, Integer> tmp = new HashMap<String, Integer>();
        try {
            StatusBarNotification[] list = getActiveNotifications();
            if (list != null) {
                for (StatusBarNotification s : list) {
                    Notification n = s.getNotification();
                    if (s.isOngoing() || (n.flags & Notification.FLAG_GROUP_SUMMARY) != 0) continue;
                    int add = n.number > 0 ? n.number : 1;
                    Integer old = tmp.get(s.getPackageName());
                    tmp.put(s.getPackageName(), (old == null ? 0 : old) + add);
                }
            }
        } catch (Throwable ignored) { }
        COUNTS.clear();
        COUNTS.putAll(tmp);
        fire();
    }
}
