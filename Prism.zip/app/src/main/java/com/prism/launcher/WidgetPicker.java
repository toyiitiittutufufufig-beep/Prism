package com.prism.launcher;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProviderInfo;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** List of every widget installed apps offer, with previews. */
public class WidgetPicker {
    private static final ExecutorService POOL = Executors.newFixedThreadPool(2);
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    public static View build(final LauncherActivity a) {
        final Context c = a;
        final PackageManager pm = c.getPackageManager();
        final List<AppWidgetProviderInfo> list = new ArrayList<AppWidgetProviderInfo>();
        try {
            for (AppWidgetProviderInfo p : AppWidgetManager.getInstance(c).getInstalledProviders()) {
                if ((p.widgetCategory & AppWidgetProviderInfo.WIDGET_CATEGORY_HOME_SCREEN) != 0) list.add(p);
            }
        } catch (Throwable ignored) { }
        final java.util.Map<AppWidgetProviderInfo, String> names = new java.util.HashMap<AppWidgetProviderInfo, String>();
        for (AppWidgetProviderInfo p : list) {
            String app;
            try {
                app = String.valueOf(pm.getApplicationLabel(pm.getApplicationInfo(p.provider.getPackageName(), 0)));
            } catch (Throwable e) {
                app = p.provider.getPackageName();
            }
            names.put(p, app);
        }
        Collections.sort(list, new Comparator<AppWidgetProviderInfo>() {
            @Override public int compare(AppWidgetProviderInfo x, AppWidgetProviderInfo y) {
                int d = names.get(x).compareToIgnoreCase(names.get(y));
                return d != 0 ? d : String.valueOf(x.loadLabel(pm)).compareToIgnoreCase(String.valueOf(y.loadLabel(pm)));
            }
        });

        LinearLayout root = new LinearLayout(c);
        root.setOrientation(LinearLayout.VERTICAL);
        TextView title = new TextView(c);
        title.setText(R.string.pick_widget);
        title.setTextColor(0xFFFFFFFF);
        title.setTextSize(20);
        title.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        title.setPadding(Util.dp(c, 22), Util.dp(c, 20), Util.dp(c, 22), Util.dp(c, 10));
        root.addView(title);

        RecyclerView rv = new RecyclerView(c);
        rv.setLayoutManager(new LinearLayoutManager(c));
        rv.setOverScrollMode(View.OVER_SCROLL_NEVER);
        rv.setAdapter(new RecyclerView.Adapter<RecyclerView.ViewHolder>() {
            @Override public int getItemCount() { return list.size(); }

            @Override public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup p, int t) {
                LinearLayout row = new LinearLayout(c);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setPadding(Util.dp(c, 22), Util.dp(c, 8), Util.dp(c, 22), Util.dp(c, 8));
                row.setLayoutParams(new RecyclerView.LayoutParams(-1, -2));
                ImageView iv = new ImageView(c);
                iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
                iv.setId(1);
                row.addView(iv, new LinearLayout.LayoutParams(Util.dp(c, 84), Util.dp(c, 64)));
                LinearLayout col = new LinearLayout(c);
                col.setOrientation(LinearLayout.VERTICAL);
                LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(0, -2, 1f);
                clp.leftMargin = Util.dp(c, 16);
                TextView t1 = new TextView(c);
                t1.setId(2);
                t1.setTextColor(0xFFFFFFFF);
                t1.setTextSize(16);
                t1.setSingleLine(true);
                TextView t2 = new TextView(c);
                t2.setId(3);
                t2.setTextColor(0x99FFFFFF);
                t2.setTextSize(13);
                t2.setSingleLine(true);
                col.addView(t1);
                col.addView(t2);
                row.addView(col, clp);
                return new RecyclerView.ViewHolder(row) { };
            }

            @Override public void onBindViewHolder(RecyclerView.ViewHolder h, int pos) {
                final AppWidgetProviderInfo p = list.get(pos);
                final ImageView iv = (ImageView) h.itemView.findViewById(1);
                ((TextView) h.itemView.findViewById(2)).setText(p.loadLabel(pm));
                int[] cells = a.cellsFor(p);
                ((TextView) h.itemView.findViewById(3)).setText(names.get(p) + "  ·  " + cells[0] + " × " + cells[1]);
                iv.setImageDrawable(null);
                iv.setTag(p);
                POOL.execute(() -> {
                    Drawable d = null;
                    try {
                        d = p.loadPreviewImage(c, 0);
                        if (d == null) d = p.loadIcon(c, 0);
                    } catch (Throwable ignored) { }
                    final Drawable fd = d;
                    MAIN.post(() -> {
                        if (iv.getTag() == p && fd != null) iv.setImageDrawable(fd);
                    });
                });
                h.itemView.setOnClickListener(v -> a.addWidget(p));
            }
        });
        root.addView(rv, new LinearLayout.LayoutParams(-1, 0, 1f));
        return root;
    }
}
