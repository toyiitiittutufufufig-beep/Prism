package com.prism.launcher;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONObject;

/** All settings in one place. Anything that changes bumps {@link #stamp} so the home screen knows to rebuild. */
public class Prefs {
    public static final String COLS = "cols", ROWS = "rows", DOCK = "dock", ICON = "icon_dp", LABELS = "labels",
            SHAPE = "shape", GLASS = "glass", PACK = "pack", THEME = "theme", BG = "bg", PHOTO = "photo",
            DCOLS = "dcols", ALPHA = "alpha", G_DOWN = "g_down", G_DOUBLE = "g_double", G_2UP = "g_2up",
            G_2DOWN = "g_2down", HIDDEN = "hidden", PAGES = "pages", ITEMS = "items", INIT = "init",
            LOCK = "lock", SORT = "sort", BADGE = "badge", HIDE_BAR = "hide_bar", DIM = "dim", RESTORED = "restored",
            THEMED = "themed", ROTATE = "rotate", DOCK_GLASS = "dock_glass",
            ISLAND = "island", ISLAND_IDLE = "island_idle", ISLAND_X = "island_x", ISLAND_Y = "island_y", ISLAND_SCALE = "island_scale";

    public static volatile int stamp = 0;
    private static Prefs inst;
    private final SharedPreferences sp;

    private Prefs(Context c) {
        sp = c.getApplicationContext().getSharedPreferences("prism", Context.MODE_PRIVATE);
    }

    public static synchronized Prefs get(Context c) {
        if (inst == null) inst = new Prefs(c);
        return inst;
    }

    public int i(String k, int d) { return sp.getInt(k, d); }
    public boolean b(String k, boolean d) { return sp.getBoolean(k, d); }
    public String s(String k, String d) { return sp.getString(k, d); }

    public void put(String k, int v) { sp.edit().putInt(k, v).apply(); stamp++; }
    public void put(String k, boolean v) { sp.edit().putBoolean(k, v).apply(); stamp++; }
    public void put(String k, String v) { sp.edit().putString(k, v).apply(); stamp++; }

    /** Saves without telling the home screen to rebuild (usage counts, custom names). */
    public void putQuiet(String k, String v) { sp.edit().putString(k, v).apply(); }

    /** Everything (layout + settings) as JSON, for backup. */
    public String exportJson() {
        try {
            JSONObject o = new JSONObject();
            for (Map.Entry<String, ?> e : sp.getAll().entrySet()) {
                Object v = e.getValue();
                JSONObject t = new JSONObject();
                if (v instanceof Integer) t.put("t", "i").put("v", v);
                else if (v instanceof Boolean) t.put("t", "b").put("v", v);
                else if (v instanceof String) t.put("t", "s").put("v", v);
                else if (v instanceof Set) t.put("t", "ss").put("v", new JSONArray((Set<?>) v));
                else continue;
                o.put(e.getKey(), t);
            }
            return o.toString();
        } catch (Throwable e) {
            return "{}";
        }
    }

    public boolean importJson(String json) {
        try {
            JSONObject o = new JSONObject(json);
            SharedPreferences.Editor ed = sp.edit();
            ed.clear();
            java.util.Iterator<String> it = o.keys();
            while (it.hasNext()) {
                String k = it.next();
                JSONObject t = o.getJSONObject(k);
                String ty = t.getString("t");
                if (ty.equals("i")) ed.putInt(k, t.getInt("v"));
                else if (ty.equals("b")) ed.putBoolean(k, t.getBoolean("v"));
                else if (ty.equals("s")) ed.putString(k, t.getString("v"));
                else if (ty.equals("ss")) {
                    JSONArray a = t.getJSONArray("v");
                    Set<String> s = new HashSet<String>();
                    for (int i = 0; i < a.length(); i++) s.add(a.getString(i));
                    ed.putStringSet(k, s);
                }
            }
            ed.putBoolean(RESTORED, true);
            ed.apply();
            stamp++;
            return true;
        } catch (Throwable e) {
            return false;
        }
    }

    public Set<String> hidden() { return new HashSet<String>(sp.getStringSet(HIDDEN, new HashSet<String>())); }
    public void setHidden(Set<String> s) { sp.edit().putStringSet(HIDDEN, s).apply(); stamp++; }

    // typed shortcuts
    public int cols() { return i(COLS, 4); }
    public int rows() { return i(ROWS, 6); }
    public int dockCount() { return i(DOCK, 5); }
    public int iconDp() { return i(ICON, 58); }
    public boolean labels() { return b(LABELS, true); }
    public int shape() { return i(SHAPE, 1); }
    public boolean glass() { return b(GLASS, true); }
    public String pack() { return s(PACK, ""); }
    public int theme() { return i(THEME, 0); }
    public int bg() { return i(BG, 0); }
    public int drawerCols() { return i(DCOLS, 4); }
    public boolean alphabet() { return b(ALPHA, true); }
}
