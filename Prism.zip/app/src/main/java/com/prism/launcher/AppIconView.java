package com.prism.launcher;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.text.TextPaint;
import android.text.TextUtils;
import android.view.View;

/** One app: its icon, its name, and an unread badge. Used on the home screen, in the dock and in the drawer. */
public class AppIconView extends View {
    public AppInfo app;
    public ItemInfo item;
    public Bitmap icon;
    private final TextPaint text = new TextPaint(Paint.ANTI_ALIAS_FLAG);
    private final TextPaint badgeText = new TextPaint(Paint.ANTI_ALIAS_FLAG);
    private final Paint bmp = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);
    private final Paint badge = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF dst = new RectF();
    private boolean showLabel = true;
    private int iconPx, badgeMode;
    private float density;

    public AppIconView(Context c) {
        super(c);
        density = c.getResources().getDisplayMetrics().density;
        text.setColor(0xFFFFFFFF);
        text.setTextAlign(Paint.Align.CENTER);
        text.setTextSize(11.5f * density);
        text.setShadowLayer(3f * density, 0, 1f * density, 0xAA000000);
        badgeText.setColor(0xFFFFFFFF);
        badgeText.setTextAlign(Paint.Align.CENTER);
        badgeText.setTypeface(Typeface.DEFAULT_BOLD);
        badgeText.setTextSize(10f * density);
        badge.setColor(0xFFFF3B5C);
    }

    public void bind(final AppInfo a, ItemInfo it, boolean label) {
        app = a;
        item = it;
        showLabel = label;
        Prefs p = Prefs.get(getContext());
        iconPx = Util.dp(getContext(), p.iconDp());
        badgeMode = p.i(Prefs.BADGE, 1);
        icon = null;
        invalidate();
        if (a != null) {
            IconCache.load(getContext(), a, iconPx, b -> {
                if (app == a) {
                    icon = b;
                    invalidate();
                }
            });
        }
    }

    @Override
    public void setPressed(boolean pressed) {
        super.setPressed(pressed);
        animate().scaleX(pressed ? 0.9f : 1f).scaleY(pressed ? 0.9f : 1f).setDuration(110).start();
    }

    @Override
    protected void onDraw(Canvas c) {
        if (app == null) return;
        int w = getWidth(), h = getHeight();
        float labelH = showLabel ? text.getTextSize() * 1.5f : 0f;
        float gap = showLabel ? 4f * density : 0f;
        float size = Math.min(iconPx, Math.min(w * 0.88f, (h - labelH - gap) * 0.96f));
        float top = (h - (size + gap + labelH)) / 2f;
        float left = (w - size) / 2f;
        if (icon != null) {
            dst.set(left, top, left + size, top + size);
            c.drawBitmap(icon, null, dst, bmp);
        }
        if (showLabel) {
            CharSequence t = TextUtils.ellipsize(app.label, text, w - 6 * density, TextUtils.TruncateAt.END);
            c.drawText(t, 0, t.length(), w / 2f, top + size + gap + text.getTextSize() * 1.05f, text);
        }
        if (badgeMode != 0) {
            int n = PrismNotificationService.count(app.comp.getPackageName());
            if (n > 0) drawBadge(c, left + size - 3 * density, top + 3 * density, n, badgeMode == 2, badge, badgeText, density);
        }
    }

    /** Red dot (or a number) in the corner of an icon. Shared with folders. */
    public static void drawBadge(Canvas c, float cx, float cy, int n, boolean number, Paint bg, TextPaint tp, float density) {
        if (!number) {
            c.drawCircle(cx, cy, 6.5f * density, bg);
            return;
        }
        String s = n > 99 ? "99+" : String.valueOf(n);
        float r = 9f * density;
        float w = Math.max(r * 2, tp.measureText(s) + 8 * density);
        RectF rr = new RectF(cx - w / 2f, cy - r, cx + w / 2f, cy + r);
        c.drawRoundRect(rr, r, r, bg);
        c.drawText(s, cx, cy + tp.getTextSize() * 0.35f, tp);
    }
}
