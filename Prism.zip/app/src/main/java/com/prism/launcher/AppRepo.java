package com.prism.launcher;

import android.app.ActivityOptions;
import android.content.ComponentName;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.LauncherActivityInfo;
import android.content.pm.LauncherApps;
import android.graphics.Rect;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Process;
import android.os.UserHandle;
import android.os.UserManager;
import android.view.View;
import android.widget.Toast;
import java.text.Collator;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;
import org.json.JSONArray;
import org.json.JSONObject;

/** Every launchable app, kept up to date when apps are installed / removed / updated. */
public class AppRepo {
    private static AppRepo inst;

    public static synchronized AppRepo get(Context c) {
        if (inst == null) inst = new AppRepo(c.getApplicationContext());
        return inst;
    }

    private final Context ctx;
    private final LauncherApps la;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final CopyOnWriteArrayList<Runnable> listeners = new CopyOnWriteArrayList<Runnable>();
    private List<AppInfo> all = new ArrayList<AppInfo>();
    private Map<String, AppInfo> byKey = new HashMap<String, AppInfo>();
    private JSONObject usage;

    private AppRepo(Context c) {
        ctx = c;
        la = (LauncherApps) c.getSystemService(Context.LAUNCHER_APPS_SERVICE);
        reload();
        la.registerCallback(new LauncherApps.Callback() {
            @Override public void onPackageRemoved(String p, UserHandle u) { changed(); }
            @Override public void onPackageAdded(String p, UserHandle u) { changed(); }
            @Override public void onPackageChanged(String p, UserHandle u) { changed(); }
            @Override public void onPackagesAvailable(String[] p, UserHandle u, boolean r) { changed(); }
            @Override public void onPackagesUnavailable(String[] p, UserHandle u, boolean r) { changed(); }
        });
    }

    private void changed() {
        main.post(() -> {
            reload();
            for (Runnable r : listeners) r.run();
        });
    }

    private JSONObject customLabels() {
        try {
            return new JSONObject(Prefs.get(ctx).s("custom_labels", "{}"));
        } catch (Throwable e) {
            return new JSONObject();
        }
    }

    /** Empty text puts the original name back. */
    public void setCustomLabel(String key, String label) {
        JSONObject o = customLabels();
        try {
            if (label == null || label.trim().length() == 0) o.remove(key); else o.put(key, label.trim());
        } catch (Throwable ignored) { }
        Prefs.get(ctx).putQuiet("custom_labels", o.toString());
        changed();
    }

    private synchronized JSONObject usage() {
        if (usage == null) {
            try {
                usage = new JSONObject(Prefs.get(ctx).s("usage", "{}"));
            } catch (Throwable e) {
                usage = new JSONObject();
            }
        }
        return usage;
    }

    /** {times launched, last launched (ms)} */
    public long[] usageOf(String key) {
        JSONArray a = usage().optJSONArray(key);
        return a == null ? new long[] {0, 0} : new long[] {a.optLong(0), a.optLong(1)};
    }

    private void record(String key) {
        try {
            long[] u = usageOf(key);
            usage().put(key, new JSONArray().put(u[0] + 1).put(System.currentTimeMillis()));
            Prefs.get(ctx).putQuiet("usage", usage().toString());
        } catch (Throwable ignored) { }
    }

    public void addListener(Runnable r) { if (!listeners.contains(r)) listeners.add(r); }
    public void removeListener(Runnable r) { listeners.remove(r); }

    public synchronized void reload() {
        List<AppInfo> out = new ArrayList<AppInfo>();
        Map<String, AppInfo> map = new HashMap<String, AppInfo>();
        JSONObject custom = customLabels();
        try {
            UserManager um = (UserManager) ctx.getSystemService(Context.USER_SERVICE);
            UserHandle me = Process.myUserHandle();
            for (UserHandle u : la.getProfiles()) {
                boolean mine = u.equals(me);
                String suffix = mine ? "" : "#" + um.getSerialNumberForUser(u);
                for (LauncherActivityInfo li : la.getActivityList(null, u)) {
                    AppInfo a = new AppInfo();
                    a.comp = li.getComponentName();
                    a.key = a.comp.flattenToString() + suffix;
                    CharSequence l = li.getLabel();
                    a.label = custom.optString(a.key, l == null ? a.comp.getPackageName() : l.toString());
                    a.lower = a.label.toLowerCase();
                    a.info = li;
                    a.user = u;
                    a.work = !mine;
                    a.system = (li.getApplicationInfo().flags & ApplicationInfo.FLAG_SYSTEM) != 0;
                    out.add(a);
                    map.put(a.key, a);
                }
            }
        } catch (Throwable ignored) { }
        final Collator col = Collator.getInstance();
        Collections.sort(out, new Comparator<AppInfo>() {
            @Override public int compare(AppInfo x, AppInfo y) { return col.compare(x.label, y.label); }
        });
        all = out;
        byKey = map;
    }

    public synchronized List<AppInfo> all() { return all; }

    public synchronized List<AppInfo> visible() {
        Set<String> hid = Prefs.get(ctx).hidden();
        List<AppInfo> out = new ArrayList<AppInfo>();
        for (AppInfo a : all) if (!hid.contains(a.key)) out.add(a);
        return out;
    }

    public synchronized AppInfo find(String key) { return byKey.get(key); }

    public synchronized AppInfo find(ComponentName cn) { return cn == null ? null : byKey.get(cn.flattenToString()); }

    /** Starts an app (in the right profile) with a zoom-out-of-the-icon animation. */
    public void launch(AppInfo app, View src) {
        record(app.key);
        try {
            Rect r = null;
            Bundle opts = null;
            if (src != null) {
                int[] loc = new int[2];
                src.getLocationOnScreen(loc);
                r = new Rect(loc[0], loc[1], loc[0] + src.getWidth(), loc[1] + src.getHeight());
                opts = ActivityOptions.makeClipRevealAnimation(src, 0, 0, src.getWidth(), src.getHeight()).toBundle();
            }
            la.startMainActivity(app.comp, app.user, r, opts);
        } catch (Throwable e) {
            Toast.makeText(ctx, R.string.not_available, Toast.LENGTH_SHORT).show();
        }
    }

    public void launch(ComponentName cn, View src) {
        AppInfo a = find(cn);
        if (a != null) launch(a, src);
    }
}
