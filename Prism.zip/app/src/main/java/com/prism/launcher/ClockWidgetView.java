package com.prism.launcher;

import android.content.Context;
import android.graphics.Typeface;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextClock;

/** The built-in glass clock + date card. */
public class ClockWidgetView extends GlassView {
    public ClockWidgetView(Context c) {
        super(c);
        setRadiusDp(30);
        LinearLayout col = new LinearLayout(c);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER_VERTICAL);
        col.setPadding(Util.dp(c, 22), 0, Util.dp(c, 22), 0);

        TextClock time = new TextClock(c);
        time.setFormat12Hour("h:mm");
        time.setFormat24Hour("HH:mm");
        time.setTextColor(0xFFFFFFFF);
        time.setTextSize(64);
        time.setTypeface(Typeface.DEFAULT_BOLD);
        time.setIncludeFontPadding(false);
        time.setShadowLayer(8, 0, 2, 0x55000000);

        TextClock date = new TextClock(c);
        date.setFormat12Hour("EEEE, d MMMM");
        date.setFormat24Hour("EEEE, d MMMM");
        date.setTextColor(0xCCFFFFFF);
        date.setTextSize(17);

        col.addView(time);
        col.addView(date);
        addView(col, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
    }
}
