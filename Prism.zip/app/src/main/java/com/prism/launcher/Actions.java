package com.prism.launcher;

import android.accessibilityservice.AccessibilityService;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.widget.Toast;

/** What a gesture can do. Stored in settings as a short string. */
public class Actions {
    public static final String[] IDS = {"none", "drawer", "notifications", "quick_settings", "lock", "recents", "search", "torch", "edit", "settings"};
    public static final int[] LABELS = {R.string.a_none, R.string.a_drawer, R.string.a_notifications, R.string.a_quick,
            R.string.a_lock, R.string.a_recents, R.string.a_search, R.string.a_torch, R.string.a_edit, R.string.a_settings};
    private static boolean torchOn = false;

    public static String label(Context c, String id) {
        for (int i = 0; i < IDS.length; i++) if (IDS[i].equals(id)) return c.getString(LABELS[i]);
        if (id.startsWith("app:")) {
            AppInfo a = AppRepo.get(c).find(id.substring(4));
            return a != null ? a.label : c.getString(R.string.a_app);
        }
        return c.getString(R.string.a_none);
    }

    public static void run(LauncherActivity a, String id) {
        switch (id) {
            case "none": return;
            case "drawer": a.openDrawer(false); return;
            case "search": a.openDrawer(true); return;
            case "edit": a.showEditSheet(); return;
            case "settings": a.startActivity(new Intent(a, SettingsActivity.class)); return;
            case "notifications": expand(a, false); return;
            case "quick_settings": expand(a, true); return;
            case "lock": global(a, AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN); return;
            case "recents": global(a, AccessibilityService.GLOBAL_ACTION_RECENTS); return;
            case "torch": torch(a); return;
            default:
                if (id.startsWith("app:")) {
                    AppInfo ai = AppRepo.get(a).find(id.substring(4));
                    if (ai != null) AppRepo.get(a).launch(ai, null);
                }
        }
    }

    private static void global(Context c, int action) {
        if (!PrismAccessibilityService.run(action)) {
            Toast.makeText(c, R.string.need_a11y, Toast.LENGTH_LONG).show();
        }
    }

    private static void expand(Context c, boolean quick) {
        try {
            Object sb = c.getSystemService("statusbar");
            Class.forName("android.app.StatusBarManager")
                    .getMethod(quick ? "expandSettingsPanel" : "expandNotificationsPanel").invoke(sb);
            return;
        } catch (Throwable ignored) { }
        global(c, quick ? AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS : AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS);
    }

    private static void torch(Context c) {
        try {
            CameraManager cm = (CameraManager) c.getSystemService(Context.CAMERA_SERVICE);
            for (String id : cm.getCameraIdList()) {
                Boolean f = cm.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
                if (f != null && f) {
                    torchOn = !torchOn;
                    cm.setTorchMode(id, torchOn);
                    return;
                }
            }
        } catch (Throwable ignored) { }
        Toast.makeText(c, R.string.not_available, Toast.LENGTH_SHORT).show();
    }
}
