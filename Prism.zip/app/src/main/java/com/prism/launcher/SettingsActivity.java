package com.prism.launcher;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.WallpaperManager;
import android.app.role.RoleManager;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.widget.Toast;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.function.IntConsumer;

/** Glass settings page. Opens from the Prism app icon (and from the home screen's edit sheet). */
public class SettingsActivity extends Activity {
    private static final int REQ_PHOTO = 7, REQ_ROLE = 8, REQ_BACKUP = 9, REQ_RESTORE = 10;

    private Prefs p;
    private LinearLayout list;
    private int insetTop, insetBottom;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        p = Prefs.get(this);
        FrameLayout root = new FrameLayout(this);
        root.addView(new BackdropView(this), new FrameLayout.LayoutParams(-1, -1));
        ScrollView sv = new ScrollView(this);
        sv.setOverScrollMode(View.OVER_SCROLL_NEVER);
        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        sv.addView(list, new FrameLayout.LayoutParams(-1, -2));
        root.addView(sv, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);
        root.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        root.setOnApplyWindowInsetsListener((v, ins) -> {
            insetTop = ins.getSystemWindowInsetTop();
            insetBottom = ins.getSystemWindowInsetBottom();
            build();
            return ins;
        });
        build();
    }

    @Override
    protected void onResume() {
        super.onResume();
        build();
    }

    // ------------------------------------------------------------ building blocks

    private int dp(float v) { return Util.dp(this, v); }

    private void text(LinearLayout parent, String s, float sp, int color, boolean bold, int top) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.topMargin = dp(top);
        parent.addView(t, lp);
    }

    private void section(String s) {
        TextView t = new TextView(this);
        t.setText(s.toUpperCase());
        t.setTextSize(12);
        t.setTextColor(Themes.get(p.theme()).accent);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setLetterSpacing(0.12f);
        t.setPadding(dp(26), dp(22), dp(20), dp(8));
        list.addView(t);
    }

    private GlassView card() {
        GlassView g = new GlassView(this);
        g.setRadiusDp(22);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(dp(16), dp(5), dp(16), dp(5));
        list.addView(g, lp);
        return g;
    }

    private void row(String title, String sub, final Runnable click) {
        GlassView g = card();
        g.setClickable(true);
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(20), dp(15), dp(20), dp(15));
        text(c, title, 16, 0xFFFFFFFF, false, 0);
        if (sub != null && sub.length() > 0) text(c, sub, 13, 0xAAFFFFFF, false, 2);
        g.addView(c, new FrameLayout.LayoutParams(-1, -2));
        g.setOnClickListener(v -> click.run());
    }

    private void toggle(String title, final String key, boolean def) {
        GlassView g = card();
        LinearLayout c = new LinearLayout(this);
        c.setGravity(Gravity.CENTER_VERTICAL);
        c.setPadding(dp(20), dp(10), dp(16), dp(10));
        TextView t = new TextView(this);
        t.setText(title);
        t.setTextSize(16);
        t.setTextColor(0xFFFFFFFF);
        c.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
        Switch sw = new Switch(this);
        sw.setChecked(p.b(key, def));
        sw.setOnCheckedChangeListener((v, on) -> {
            p.put(key, on);
            Island.ensure(SettingsActivity.this);
        });
        c.addView(sw);
        g.addView(c, new FrameLayout.LayoutParams(-1, -2));
    }

    private void slider(String title, final String key, final int min, final int max, int def) {
        GlassView g = card();
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(20), dp(14), dp(20), dp(10));
        final TextView t = new TextView(this);
        t.setTextSize(16);
        t.setTextColor(0xFFFFFFFF);
        int cur = p.i(key, def);
        t.setText(title + "  ·  " + cur);
        c.addView(t);
        SeekBar sb = new SeekBar(this);
        sb.setMax(max - min);
        sb.setProgress(cur - min);
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int v, boolean user) { t.setText(title(t) + "  ·  " + (v + min)); }
            @Override public void onStartTrackingTouch(SeekBar s) { }
            @Override public void onStopTrackingTouch(SeekBar s) {
                p.put(key, s.getProgress() + min);
                Island.ensure(SettingsActivity.this);
            }
        });
        c.addView(sb);
        g.addView(c, new FrameLayout.LayoutParams(-1, -2));
    }

    private static String title(TextView t) {
        String s = t.getText().toString();
        int i = s.lastIndexOf("  ·  ");
        return i > 0 ? s.substring(0, i) : s;
    }

    private AlertDialog.Builder dialog(String title) {
        return new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert).setTitle(title);
    }

    private void choose(String title, String[] labels, int selected, final IntConsumer cb) {
        dialog(title).setSingleChoiceItems(labels, selected, (d, which) -> {
            d.dismiss();
            cb.accept(which);
            build();
        }).setNegativeButton(R.string.cancel, null).show();
    }

    // ------------------------------------------------------------ page

    private boolean isDefaultHome() {
        try {
            Intent i = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME);
            ResolveInfo ri = getPackageManager().resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY);
            return ri != null && getPackageName().equals(ri.activityInfo.packageName);
        } catch (Throwable e) {
            return false;
        }
    }

    private void build() {
        Island.ensure(this);
        list.removeAllViews();
        list.setPadding(0, insetTop + dp(14), 0, insetBottom + dp(28));
        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.VERTICAL);
        head.setPadding(dp(26), dp(8), dp(20), dp(4));
        text(head, getString(R.string.app_name), 34, 0xFFFFFFFF, true, 0);
        list.addView(head);

        if (!isDefaultHome()) {
            section(getString(R.string.sec_system));
            row(getString(R.string.default_launcher), getString(R.string.default_launcher_sub), this::makeDefault);
        }

        section(getString(R.string.sec_look));
        String[] themes = new String[Themes.ALL.length];
        for (int i = 0; i < themes.length; i++) themes[i] = Themes.ALL[i].name;
        row(getString(R.string.theme), themes[p.theme()], () -> choose(getString(R.string.theme), themes, p.theme(), i -> p.put(Prefs.THEME, i)));
        row(getString(R.string.icon_shape), ShapeUtil.NAMES[p.shape()],
                () -> choose(getString(R.string.icon_shape), ShapeUtil.NAMES, p.shape(), i -> p.put(Prefs.SHAPE, i)));
        toggle(getString(R.string.glass_tiles), Prefs.GLASS, true);
        toggle(getString(R.string.themed_icons), Prefs.THEMED, false);
        slider(getString(R.string.icon_size), Prefs.ICON, 44, 76, 58);
        toggle(getString(R.string.show_labels), Prefs.LABELS, true);
        final List<String[]> packs = IconPack.installed(this);
        String cur = getString(R.string.icon_pack_none);
        for (String[] pk : packs) if (pk[0].equals(p.pack())) cur = pk[1];
        row(getString(R.string.icon_pack), cur, () -> {
            String[] labels = new String[packs.size() + 1];
            labels[0] = getString(R.string.icon_pack_none);
            int sel = 0;
            for (int i = 0; i < packs.size(); i++) {
                labels[i + 1] = packs.get(i)[1];
                if (packs.get(i)[0].equals(p.pack())) sel = i + 1;
            }
            choose(getString(R.string.icon_pack), labels, sel, i -> p.put(Prefs.PACK, i == 0 ? "" : packs.get(i - 1)[0]));
        });

        section(getString(R.string.sec_home));
        String[] cols = {"4", "5", "6"}, rows = {"5", "6", "7"}, docks = {"4", "5"};
        row(getString(R.string.grid_cols), String.valueOf(p.cols()),
                () -> choose(getString(R.string.grid_cols), cols, p.cols() - 4, i -> p.put(Prefs.COLS, i + 4)));
        row(getString(R.string.grid_rows), String.valueOf(p.rows()),
                () -> choose(getString(R.string.grid_rows), rows, p.rows() - 5, i -> p.put(Prefs.ROWS, i + 5)));
        row(getString(R.string.dock_icons), String.valueOf(p.dockCount()),
                () -> choose(getString(R.string.dock_icons), docks, p.dockCount() - 4, i -> p.put(Prefs.DOCK, i + 4)));
        toggle(getString(R.string.lock_row), Prefs.LOCK, false);
        toggle(getString(R.string.hide_bar), Prefs.HIDE_BAR, false);
        toggle(getString(R.string.rotate), Prefs.ROTATE, false);
        toggle(getString(R.string.dock_glass), Prefs.DOCK_GLASS, true);

        section(getString(R.string.sec_wallpaper));
        row(getString(R.string.bg_style), Scenes.NAMES[p.bg()],
                () -> choose(getString(R.string.bg_style), Scenes.NAMES, p.bg(), i -> p.put(Prefs.BG, i)));
        row(getString(R.string.pick_photo), null, () -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("image/*");
            startActivityForResult(i, REQ_PHOTO);
        });
        slider(getString(R.string.dim), Prefs.DIM, 0, 60, 0);
        row(getString(R.string.set_live), null, () -> {
            try {
                startActivity(new Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER)
                        .putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT, new ComponentName(this, PrismWallpaperService.class)));
            } catch (Throwable e) {
                startActivity(new Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER));
            }
        });

        section(getString(R.string.sec_island));
        toggle(getString(R.string.island_toggle), Prefs.ISLAND, false);
        toggle(getString(R.string.island_idle), Prefs.ISLAND_IDLE, true);
        slider(getString(R.string.island_x), Prefs.ISLAND_X, -60, 60, 0);
        slider(getString(R.string.island_y), Prefs.ISLAND_Y, -12, 30, 0);
        slider(getString(R.string.island_scale), Prefs.ISLAND_SCALE, 70, 170, 100);
        row(getString(R.string.island_status), Island.status(this), () -> Island.ensure(this));
        row(getString(R.string.island_overlay_perm), Settings.canDrawOverlays(this) ? "ON" : "OFF", () -> startActivity(
                new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()))));
        row(getString(R.string.island_preview), null, () -> Island.preview(this));

        section(getString(R.string.sec_gestures));
        gesture(R.string.g_swipe_down, Prefs.G_DOWN, "notifications");
        gesture(R.string.g_double_tap, Prefs.G_DOUBLE, "lock");
        gesture(R.string.g_two_up, Prefs.G_2UP, "search");
        gesture(R.string.g_two_down, Prefs.G_2DOWN, "quick_settings");
        row(getString(R.string.enable_a11y), PrismAccessibilityService.enabled() ? "ON" : "OFF",
                () -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));

        section(getString(R.string.sec_drawer));
        String[] dcols = {"3", "4", "5", "6"};
        row(getString(R.string.drawer_cols), String.valueOf(p.drawerCols()),
                () -> choose(getString(R.string.drawer_cols), dcols, p.drawerCols() - 3, i -> p.put(Prefs.DCOLS, i + 3)));
        toggle(getString(R.string.alphabet_bar), Prefs.ALPHA, true);
        row(getString(R.string.hidden_apps), String.valueOf(p.hidden().size()), this::pickHidden);
        final String[] sorts = {getString(R.string.sort_az), getString(R.string.sort_most), getString(R.string.sort_recent)};
        row(getString(R.string.sort_apps), sorts[p.i(Prefs.SORT, 0)],
                () -> choose(getString(R.string.sort_apps), sorts, p.i(Prefs.SORT, 0), i -> p.put(Prefs.SORT, i)));

        section(getString(R.string.sec_badges));
        final String[] badgeModes = {getString(R.string.badge_off), getString(R.string.badge_dots), getString(R.string.badge_numbers)};
        row(getString(R.string.badges), badgeModes[p.i(Prefs.BADGE, 1)],
                () -> choose(getString(R.string.badges), badgeModes, p.i(Prefs.BADGE, 1), i -> p.put(Prefs.BADGE, i)));
        row(getString(R.string.notif_access), PrismNotificationService.connected() ? "ON" : "OFF",
                () -> startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)));

        section(getString(R.string.sec_backup));
        row(getString(R.string.backup), null, () -> {
            Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
                    .setType("application/json").putExtra(Intent.EXTRA_TITLE, "prism-backup.json");
            startActivityForResult(i, REQ_BACKUP);
        });
        row(getString(R.string.restore), null, () -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*");
            startActivityForResult(i, REQ_RESTORE);
        });
        row(getString(R.string.reset_home), null, () -> dialog(getString(R.string.reset_home)).setMessage(R.string.reset_confirm)
                .setPositiveButton(R.string.done, (d, w) -> {
                    p.put(Prefs.ITEMS, "[]");
                    p.put(Prefs.PAGES, 1);
                    p.put(Prefs.INIT, false);
                    Toast.makeText(this, R.string.restore_done, Toast.LENGTH_SHORT).show();
                }).setNegativeButton(R.string.cancel, null).show());
    }

    private void gesture(final int titleRes, final String key, final String def) {
        row(getString(titleRes), Actions.label(this, p.s(key, def)), () -> {
            String[] labels = new String[Actions.IDS.length + 1];
            for (int i = 0; i < Actions.IDS.length; i++) labels[i] = getString(Actions.LABELS[i]);
            labels[Actions.IDS.length] = getString(R.string.a_app);
            int sel = -1;
            String cur = p.s(key, def);
            for (int i = 0; i < Actions.IDS.length; i++) if (Actions.IDS[i].equals(cur)) sel = i;
            if (sel < 0) sel = Actions.IDS.length;
            choose(getString(titleRes), labels, sel, i -> {
                if (i < Actions.IDS.length) p.put(key, Actions.IDS[i]);
                else pickApp(key);
            });
        });
    }

    private void pickApp(final String key) {
        final List<AppInfo> apps = AppRepo.get(this).all();
        String[] labels = new String[apps.size()];
        for (int i = 0; i < labels.length; i++) labels[i] = apps.get(i).label;
        dialog(getString(R.string.a_app)).setItems(labels, (d, which) -> {
            p.put(key, "app:" + apps.get(which).key);
            build();
        }).setNegativeButton(R.string.cancel, null).show();
    }

    private void pickHidden() {
        final List<AppInfo> apps = AppRepo.get(this).all();
        final Set<String> hidden = p.hidden();
        String[] labels = new String[apps.size()];
        final boolean[] checked = new boolean[apps.size()];
        for (int i = 0; i < labels.length; i++) {
            labels[i] = apps.get(i).label;
            checked[i] = hidden.contains(apps.get(i).key);
        }
        dialog(getString(R.string.hidden_apps)).setMultiChoiceItems(labels, checked, (d, which, on) -> checked[which] = on)
                .setPositiveButton(R.string.done, (d, w) -> {
                    Set<String> s = new java.util.HashSet<String>();
                    for (int i = 0; i < checked.length; i++) if (checked[i]) s.add(apps.get(i).key);
                    p.setHidden(s);
                    build();
                }).setNegativeButton(R.string.cancel, null).show();
    }

    private void makeDefault() {
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                RoleManager rm = getSystemService(RoleManager.class);
                if (rm != null && rm.isRoleAvailable(RoleManager.ROLE_HOME) && !rm.isRoleHeld(RoleManager.ROLE_HOME)) {
                    startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_HOME), REQ_ROLE);
                    return;
                }
            }
        } catch (Throwable ignored) { }
        try {
            startActivity(new Intent(Settings.ACTION_HOME_SETTINGS));
        } catch (Throwable e) {
            startActivity(new Intent(Settings.ACTION_SETTINGS));
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_PHOTO && res == RESULT_OK && data != null && data.getData() != null) {
            Uri u = data.getData();
            if (Scenes.savePhoto(this, u)) p.put(Prefs.BG, Scenes.PHOTO);
            build();
        } else if (req == REQ_ROLE) {
            build();
        } else if (req == REQ_BACKUP && res == RESULT_OK && data != null && data.getData() != null) {
            try (OutputStream out = getContentResolver().openOutputStream(data.getData())) {
                out.write(p.exportJson().getBytes("UTF-8"));
                Toast.makeText(this, R.string.backup_done, Toast.LENGTH_SHORT).show();
            } catch (Throwable e) {
                Toast.makeText(this, R.string.restore_failed, Toast.LENGTH_SHORT).show();
            }
        } else if (req == REQ_RESTORE && res == RESULT_OK && data != null && data.getData() != null) {
            boolean ok = false;
            try (InputStream in = getContentResolver().openInputStream(data.getData())) {
                ByteArrayOutputStream bo = new ByteArrayOutputStream();
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
                ok = p.importJson(bo.toString("UTF-8"));
            } catch (Throwable ignored) { }
            Toast.makeText(this, ok ? R.string.restore_done : R.string.restore_failed, Toast.LENGTH_SHORT).show();
            build();
        }
    }
}
