package com.prism.launcher;

import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.AccessibilityEvent;

/** Only used to perform "lock screen", "recents" and the notification shade from gestures. Reads nothing. */
public class PrismAccessibilityService extends AccessibilityService {
    private static PrismAccessibilityService inst;

    public static boolean run(int globalAction) {
        return inst != null && inst.performGlobalAction(globalAction);
    }

    public static boolean enabled() { return inst != null; }

    public static PrismAccessibilityService get() { return inst; }

    @Override protected void onServiceConnected() {
        inst = this;
        Island.ensure(this);
    }

    @Override public boolean onUnbind(android.content.Intent i) {
        inst = null;
        Island.ensure(getApplicationContext());
        return super.onUnbind(i);
    }
    @Override public void onAccessibilityEvent(AccessibilityEvent e) { }
    @Override public void onInterrupt() { }
}
