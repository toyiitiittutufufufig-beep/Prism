package com.prism.launcher;

import android.animation.ValueAnimator;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/** The page that slides up from the bottom with every app: blurred glass, instant search, A-Z scroller. */
public class DrawerView extends FrameLayout {
    public interface Host {
        void onApp(AppInfo a, View v);
        void onAppLong(AppInfo a, View v, float rawX, float rawY);
        void onProgress(float p);
    }

    private final Host host;
    private final BackdropView back;
    private final View scrim;
    private final LinearLayout col;
    private final EditText search;
    private final LinearLayout suggestRow;
    private final TextView suggestLabel;
    private String calc;
    private final ImageView clear;
    private final RecyclerView list;
    private final GridLayoutManager glm;
    private final AlphabetBar bar;
    private final TextView bubble;
    private final Adapter adapter = new Adapter();
    private final List<AppInfo> shown = new ArrayList<AppInfo>();
    private String query = "";
    private float progress = 0f;
    private int insetTop, insetBottom;
    private float lastRawX, lastRawY;
    private ValueAnimator anim;

    // drag-to-close
    private float sx, sy;
    private boolean closing;
    private VelocityTracker vt;

    public DrawerView(Context c, Host h) {
        super(c);
        host = h;
        setVisibility(INVISIBLE);

        back = new BackdropView(c);
        back.setBlurred(true);
        addView(back, new LayoutParams(-1, -1));
        scrim = new View(c);
        addView(scrim, new LayoutParams(-1, -1));

        col = new LinearLayout(c);
        col.setOrientation(LinearLayout.VERTICAL);
        addView(col, new LayoutParams(-1, -1));

        GlassView sb = new GlassView(c);
        sb.setRadiusDp(26);
        LinearLayout row = new LinearLayout(c);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(Util.dp(c, 16), 0, Util.dp(c, 8), 0);
        ImageView mag = new ImageView(c);
        mag.setImageResource(R.drawable.ic_search);
        mag.setAlpha(0.8f);
        row.addView(mag, new LinearLayout.LayoutParams(Util.dp(c, 20), Util.dp(c, 20)));
        search = new EditText(c);
        search.setBackground(null);
        search.setHint(R.string.search_apps);
        search.setHintTextColor(0x88FFFFFF);
        search.setTextColor(0xFFFFFFFF);
        search.setTextSize(16);
        search.setSingleLine(true);
        search.setImeOptions(EditorInfo.IME_ACTION_GO | EditorInfo.IME_FLAG_NO_EXTRACT_UI);
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f);
        slp.leftMargin = Util.dp(c, 10);
        row.addView(search, slp);
        clear = new ImageView(c);
        clear.setImageResource(R.drawable.ic_close);
        clear.setPadding(Util.dp(c, 10), Util.dp(c, 10), Util.dp(c, 10), Util.dp(c, 10));
        clear.setVisibility(GONE);
        row.addView(clear, new LinearLayout.LayoutParams(Util.dp(c, 40), Util.dp(c, 40)));
        sb.addView(row, new LayoutParams(-1, -1));
        LinearLayout.LayoutParams sbp = new LinearLayout.LayoutParams(-1, Util.dp(c, 52));
        sbp.setMargins(Util.dp(c, 18), Util.dp(c, 14), Util.dp(c, 18), Util.dp(c, 6));
        col.addView(sb, sbp);

        suggestLabel = new TextView(c);
        suggestLabel.setText(R.string.suggested);
        suggestLabel.setTextColor(0x99FFFFFF);
        suggestLabel.setTextSize(12);
        suggestLabel.setTypeface(Typeface.DEFAULT_BOLD);
        suggestLabel.setLetterSpacing(0.1f);
        suggestLabel.setPadding(Util.dp(c, 26), Util.dp(c, 10), 0, 0);
        suggestLabel.setVisibility(GONE);
        col.addView(suggestLabel);
        suggestRow = new LinearLayout(c);
        suggestRow.setPadding(Util.dp(c, 14), 0, Util.dp(c, 30), 0);
        suggestRow.setVisibility(GONE);
        col.addView(suggestRow, new LinearLayout.LayoutParams(-1, -2));

        list = new RecyclerView(c);
        glm = new GridLayoutManager(c, 4);
        glm.setSpanSizeLookup(new GridLayoutManager.SpanSizeLookup() {
            @Override public int getSpanSize(int pos) { return pos >= shown.size() ? glm.getSpanCount() : 1; }
        });
        list.setLayoutManager(glm);
        list.setAdapter(adapter);
        list.setClipToPadding(false);
        list.setOverScrollMode(OVER_SCROLL_NEVER);
        col.addView(list, new LinearLayout.LayoutParams(-1, 0, 1f));

        bar = new AlphabetBar(c);
        FrameLayout.LayoutParams blp = new FrameLayout.LayoutParams(Util.dp(c, 24), -1, Gravity.END);
        blp.topMargin = Util.dp(c, 190);
        blp.bottomMargin = Util.dp(c, 70);
        addView(bar, blp);

        bubble = new TextView(c);
        bubble.setGravity(Gravity.CENTER);
        bubble.setTextColor(0xFFFFFFFF);
        bubble.setTextSize(44);
        bubble.setTypeface(Typeface.DEFAULT_BOLD);
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(Util.dp(c, 28));
        bg.setColor(0x66000000);
        bg.setStroke(Util.dp(c, 1), 0x55FFFFFF);
        bubble.setBackground(bg);
        bubble.setVisibility(GONE);
        addView(bubble, new FrameLayout.LayoutParams(Util.dp(c, 96), Util.dp(c, 96), Gravity.CENTER));

        bar.setCb((letter, active) -> {
            if (!active) {
                bubble.setVisibility(GONE);
                return;
            }
            bubble.setText(String.valueOf(letter));
            bubble.setVisibility(VISIBLE);
            jumpTo(letter);
        });
        clear.setOnClickListener(v -> search.setText(""));
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int d) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int d) { }
            @Override public void afterTextChanged(Editable e) {
                query = e.toString();
                clear.setVisibility(query.length() > 0 ? VISIBLE : GONE);
                refresh();
            }
        });
        search.setOnEditorActionListener((v, id, ev) -> {
            if (!shown.isEmpty()) host.onApp(shown.get(0), null);
            else if (query.trim().length() > 0) webSearch(query.trim());
            return true;
        });
        applyStyle();
    }

    public void setInsets(int top, int bottom) {
        insetTop = top;
        insetBottom = bottom;
        col.setPadding(0, top, 0, 0);
        list.setPadding(Util.dp(getContext(), 8), Util.dp(getContext(), 6), Util.dp(getContext(), 24), bottom + Util.dp(getContext(), 28));
    }

    /** Re-read colors, columns etc. after settings changed. */
    public void applyStyle() {
        Prefs p = Prefs.get(getContext());
        back.reload();
        glm.setSpanCount(Math.max(3, Math.min(6, p.drawerCols())));
        bar.setVisibility(p.alphabet() ? VISIBLE : GONE);
        bar.setAccent(Themes.get(p.theme()).accent);
        int a = Build.VERSION.SDK_INT >= 31 ? 0x66 : 0xB0;
        scrim.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[] {Color.argb(a - 0x18, 0, 0, 8), Color.argb(Math.min(255, a + 0x20), 0, 0, 14)}));
        refresh();
    }

    public void refresh() {
        List<AppInfo> all = AppRepo.get(getContext()).visible();
        shown.clear();
        final String q = query.trim().toLowerCase(Locale.ROOT);
        final int sort = Prefs.get(getContext()).i(Prefs.SORT, 0);
        if (q.length() == 0) {
            shown.addAll(all);
            if (sort != 0) {
                final AppRepo repo = AppRepo.get(getContext());
                Collections.sort(shown, new Comparator<AppInfo>() {
                    @Override public int compare(AppInfo x, AppInfo y) {
                        long[] ux = repo.usageOf(x.key), uy = repo.usageOf(y.key);
                        long d = sort == 1 ? uy[0] - ux[0] : uy[1] - ux[1];
                        if (d != 0) return d > 0 ? 1 : -1;
                        return x.label.compareToIgnoreCase(y.label);
                    }
                });
            }
        } else {
            final java.util.Map<AppInfo, Integer> score = new java.util.HashMap<AppInfo, Integer>();
            for (AppInfo a : all) {
                int s = match(a, q);
                if (s >= 0) {
                    shown.add(a);
                    score.put(a, s);
                }
            }
            Collections.sort(shown, new Comparator<AppInfo>() {
                @Override public int compare(AppInfo x, AppInfo y) {
                    int d = score.get(x) - score.get(y);
                    return d != 0 ? d : x.label.compareToIgnoreCase(y.label);
                }
            });
        }
        bar.setVisibility(q.length() == 0 && sort == 0 && Prefs.get(getContext()).alphabet() ? VISIBLE : GONE);
        calc = q.length() > 0 ? Calc.format(query) : null;

        // most-launched apps on top
        suggestRow.removeAllViews();
        boolean showSug = q.length() == 0;
        if (showSug) {
            final AppRepo rp = AppRepo.get(getContext());
            List<AppInfo> top = new ArrayList<AppInfo>(all);
            Collections.sort(top, (x, y) -> Long.compare(rp.usageOf(y.key)[0], rp.usageOf(x.key)[0]));
            int max = Math.max(3, Math.min(5, Prefs.get(getContext()).drawerCols()));
            for (AppInfo ap : top) {
                if (suggestRow.getChildCount() >= max || rp.usageOf(ap.key)[0] <= 0) break;
                AppIconView iv = new AppIconView(getContext());
                iv.bind(ap, null, true);
                wire(iv, ap);
                suggestRow.addView(iv, new LinearLayout.LayoutParams(0, Util.dp(getContext(), 100), 1f));
            }
            showSug = suggestRow.getChildCount() > 0;
            while (showSug && suggestRow.getChildCount() < max) {
                suggestRow.addView(new View(getContext()), new LinearLayout.LayoutParams(0, Util.dp(getContext(), 100), 1f));
            }
        }
        suggestLabel.setVisibility(showSug ? VISIBLE : GONE);
        suggestRow.setVisibility(showSug ? VISIBLE : GONE);
        adapter.notifyDataSetChanged();
    }

    /** Redraw icons (notification badges changed). */
    public void invalidateIcons() {
        for (int i = 0; i < list.getChildCount(); i++) list.getChildAt(i).invalidate();
    }

    private static int match(AppInfo a, String q) {
        if (a.lower.startsWith(q)) return 0;
        if (a.lower.contains(" " + q)) return 1;
        StringBuilder ini = new StringBuilder();
        for (String w : a.lower.split("[\\s._-]+")) if (w.length() > 0) ini.append(w.charAt(0));
        if (q.length() > 1 && ini.toString().startsWith(q)) return 1;
        if (a.lower.contains(q)) return 2;
        if (a.comp.getPackageName().toLowerCase(Locale.ROOT).contains(q)) return 3;
        return -1;
    }

    private void jumpTo(char letter) {
        int idx = -1;
        if (letter == '#') {
            for (int i = 0; i < shown.size(); i++) if (shown.get(i).letter() == '#') { idx = i; break; }
        } else {
            for (int i = 0; i < shown.size() && idx < 0; i++) {
                char l = shown.get(i).letter();
                if (l != '#' && l >= letter) idx = i;
            }
        }
        if (idx >= 0) glm.scrollToPositionWithOffset(idx, 0);
    }

    private void copy(String s) {
        try {
            ClipboardManager cm = (ClipboardManager) getContext().getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("Prism", s));
            Toast.makeText(getContext(), R.string.copied, Toast.LENGTH_SHORT).show();
        } catch (Throwable ignored) { }
    }

    private void wire(final AppIconView v, final AppInfo a) {
        v.setOnClickListener(x -> host.onApp(a, v));
        v.setOnTouchListener((x, ev) -> {
            if (ev.getActionMasked() == MotionEvent.ACTION_DOWN) {
                lastRawX = ev.getRawX();
                lastRawY = ev.getRawY();
            }
            return false;
        });
        v.setOnLongClickListener(x -> {
            host.onAppLong(a, v, lastRawX, lastRawY);
            return true;
        });
    }

    private void webSearch(String q) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q)));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
        } catch (Throwable ignored) { }
    }

    // ------------------------------------------------------------ open / close

    public boolean isOpen() { return progress > 0.5f && getVisibility() == VISIBLE; }
    public float progress() { return progress; }

    public void setProgress(float p) {
        progress = Math.max(0f, Math.min(1f, p));
        if (progress > 0f && getVisibility() != VISIBLE) setVisibility(VISIBLE);
        setTranslationY((1f - progress) * getHeight());
        setAlpha(0.35f + 0.65f * progress);
        if (progress <= 0f) {
            setVisibility(INVISIBLE);
            hideKeyboard();
        }
        host.onProgress(progress);
    }

    public void animateTo(final boolean open, float velocity) {
        if (anim != null) anim.cancel();
        float target = open ? 1f : 0f;
        anim = ValueAnimator.ofFloat(progress, target);
        long d = Math.round(260 + 160 * Math.abs(target - progress));
        if (Math.abs(velocity) > 1500) d = Math.max(160, d - 100);
        anim.setDuration(d);
        anim.setInterpolator(new DecelerateInterpolator(1.6f));
        anim.addUpdateListener(a -> setProgress((Float) a.getAnimatedValue()));
        anim.start();
        if (!open) {
            hideKeyboard();
            search.setText("");
            list.scrollToPosition(0);
        }
    }

    public void focusSearch(boolean show) {
        if (show) {
            search.requestFocus();
            postDelayed(() -> {
                InputMethodManager im = (InputMethodManager) getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
                if (im != null) im.showSoftInput(search, 0);
            }, 300);
        }
    }

    private void hideKeyboard() {
        InputMethodManager im = (InputMethodManager) getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
        if (im != null) im.hideSoftInputFromWindow(search.getWindowToken(), 0);
        search.clearFocus();
    }

    // swipe down on the list (when it is at the top) closes the drawer
    @Override
    public boolean onInterceptTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                sx = e.getRawX();
                sy = e.getRawY();
                closing = false;
                lastRawX = sx;
                lastRawY = sy;
                break;
            case MotionEvent.ACTION_MOVE: {
                float dy = e.getRawY() - sy, dx = e.getRawX() - sx;
                float slop = ViewConfiguration.get(getContext()).getScaledTouchSlop();
                if (!closing && dy > slop * 1.5f && dy > Math.abs(dx) * 1.3f && !list.canScrollVertically(-1)) {
                    closing = true;
                    if (vt != null) vt.recycle();
                    vt = VelocityTracker.obtain();
                    return true;
                }
                break;
            }
        }
        return false;
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (vt != null) vt.addMovement(e);
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_MOVE:
                if (closing) {
                    float dy = Math.max(0, e.getRawY() - sy);
                    setProgress(1f - dy / Math.max(1, getHeight()));
                }
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                if (closing) {
                    float v = 0;
                    if (vt != null) {
                        vt.computeCurrentVelocity(1000);
                        v = vt.getYVelocity();
                    }
                    boolean open = !(v > 900 || progress < 0.72f) || v < -900;
                    animateTo(open, v);
                    closing = false;
                    if (vt != null) { vt.recycle(); vt = null; }
                }
                return true;
        }
        return true;
    }

    // ------------------------------------------------------------ adapter

    private class Adapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
        @Override public int getItemViewType(int pos) { return pos >= shown.size() ? 1 : 0; }

        @Override public int getItemCount() {
            return shown.size() + (query.trim().length() > 0 || shown.isEmpty() ? 1 : 0);
        }

        @Override public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup p, int type) {
            Context c = p.getContext();
            if (type == 1) {
                TextView t = new TextView(c);
                t.setTextColor(0xFFFFFFFF);
                t.setTextSize(15);
                t.setGravity(Gravity.CENTER);
                t.setPadding(Util.dp(c, 16), Util.dp(c, 18), Util.dp(c, 16), Util.dp(c, 18));
                t.setLayoutParams(new RecyclerView.LayoutParams(-1, -2));
                return new RecyclerView.ViewHolder(t) { };
            }
            AppIconView v = new AppIconView(c);
            v.setLayoutParams(new RecyclerView.LayoutParams(-1, Util.dp(c, 100)));
            return new RecyclerView.ViewHolder(v) { };
        }

        @Override public void onBindViewHolder(RecyclerView.ViewHolder h, int pos) {
            if (getItemViewType(pos) == 1) {
                TextView t = (TextView) h.itemView;
                boolean none = shown.isEmpty();
                String q = query.trim();
                if (calc != null) {
                    final String res = calc;
                    t.setText("= " + res + "\n" + getContext().getString(R.string.tap_copy));
                    t.setOnClickListener(v -> copy(res));
                    return;
                }
                t.setText(q.length() == 0 ? getContext().getString(R.string.no_results)
                        : (none ? getContext().getString(R.string.no_results) + "\n" : "")
                        + getContext().getString(R.string.search_web, q));
                t.setOnClickListener(q.length() == 0 ? null : (View.OnClickListener) v -> webSearch(q));
                return;
            }
            final AppInfo a = shown.get(pos);
            final AppIconView v = (AppIconView) h.itemView;
            v.bind(a, null, true);
            wire(v, a);
        }
    }
}
