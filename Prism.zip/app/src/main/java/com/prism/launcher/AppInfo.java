package com.prism.launcher;

import android.content.ComponentName;
import android.content.pm.LauncherActivityInfo;
import android.os.UserHandle;

public class AppInfo {
    public ComponentName comp;
    public String key;      // comp.flattenToString()
    public String label;
    public String lower;
    public LauncherActivityInfo info;
    public boolean system;
    public UserHandle user;
    public boolean work;

    /** A..Z or '#': used by the alphabet scroller. */
    public char letter() {
        if (label.length() == 0) return '#';
        char c = Character.toUpperCase(label.charAt(0));
        return (c >= 'A' && c <= 'Z') ? c : '#';
    }
}
