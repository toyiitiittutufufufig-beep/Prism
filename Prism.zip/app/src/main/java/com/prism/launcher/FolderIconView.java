package com.prism.launcher;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.text.TextPaint;
import android.text.TextUtils;
import android.view.View;

/** A folder: a glass tile with up to four little icons inside, and the folder's name. */
public class FolderIconView extends View {
    public ItemInfo item;
    private final Bitmap[] mini = new Bitmap[4];
    private final TextPaint text = new TextPaint(Paint.ANTI_ALIAS_FLAG);
    private final TextPaint badgeText = new TextPaint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint rim = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint bmp = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);
    private final Paint badge = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF r = new RectF();
    private final float density;
    private boolean showLabel = true;
    private int iconPx, badgeMode;

    public FolderIconView(Context c) {
        super(c);
        density = c.getResources().getDisplayMetrics().density;
        text.setColor(0xFFFFFFFF);
        text.setTextAlign(Paint.Align.CENTER);
        text.setTextSize(11.5f * density);
        text.setShadowLayer(3f * density, 0, 1f * density, 0xAA000000);
        rim.setStyle(Paint.Style.STROKE);
        badgeText.setColor(0xFFFFFFFF);
        badgeText.setTextAlign(Paint.Align.CENTER);
        badgeText.setTypeface(Typeface.DEFAULT_BOLD);
        badgeText.setTextSize(10f * density);
        badge.setColor(0xFFFF3B5C);
    }

    public void bind(final ItemInfo it, boolean label) {
        item = it;
        showLabel = label;
        Prefs p = Prefs.get(getContext());
        iconPx = Util.dp(getContext(), p.iconDp());
        badgeMode = p.i(Prefs.BADGE, 1);
        for (int i = 0; i < 4; i++) mini[i] = null;
        AppRepo repo = AppRepo.get(getContext());
        int miniPx = Math.round(iconPx * 0.42f);
        for (int i = 0; i < Math.min(4, it.apps.size()); i++) {
            final int idx = i;
            AppInfo a = repo.find(it.apps.get(i));
            if (a == null) continue;
            IconCache.load(getContext(), a, miniPx, b -> {
                if (item == it) {
                    mini[idx] = b;
                    invalidate();
                }
            });
        }
        invalidate();
    }

    public String name() {
        return item == null || item.title.length() == 0 ? getContext().getString(R.string.folder) : item.title;
    }

    @Override
    public void setPressed(boolean pressed) {
        super.setPressed(pressed);
        animate().scaleX(pressed ? 0.9f : 1f).scaleY(pressed ? 0.9f : 1f).setDuration(110).start();
    }

    @Override
    protected void onDraw(Canvas c) {
        if (item == null) return;
        int w = getWidth(), h = getHeight();
        float labelH = showLabel ? text.getTextSize() * 1.5f : 0f;
        float gap = showLabel ? 4f * density : 0f;
        float size = Math.min(iconPx, Math.min(w * 0.88f, (h - labelH - gap) * 0.96f));
        float top = (h - (size + gap + labelH)) / 2f;
        float left = (w - size) / 2f;
        float rad = size * 0.28f;

        r.set(left, top, left + size, top + size);
        fill.setShader(new LinearGradient(0, top, 0, top + size, 0x66FFFFFF, 0x30FFFFFF, Shader.TileMode.CLAMP));
        c.drawRoundRect(r, rad, rad, fill);
        rim.setStrokeWidth(Math.max(1.5f, size * 0.02f));
        rim.setShader(new LinearGradient(left, top, left + size, top + size, 0xCCFFFFFF, 0x22FFFFFF, Shader.TileMode.CLAMP));
        c.drawRoundRect(r, rad, rad, rim);

        float pad = size * 0.13f, g = size * 0.07f;
        float cell = (size - 2 * pad - g) / 2f;
        for (int i = 0; i < 4; i++) {
            if (mini[i] == null) continue;
            float x = left + pad + (i % 2) * (cell + g), y = top + pad + (i / 2) * (cell + g);
            r.set(x, y, x + cell, y + cell);
            c.drawBitmap(mini[i], null, r, bmp);
        }
        if (showLabel) {
            CharSequence t = TextUtils.ellipsize(name(), text, w - 6 * density, TextUtils.TruncateAt.END);
            c.drawText(t, 0, t.length(), w / 2f, top + size + gap + text.getTextSize() * 1.05f, text);
        }
        if (badgeMode != 0) {
            int n = 0;
            for (String k : item.apps) {
                int i = k.indexOf('/');
                if (i > 0) n += PrismNotificationService.count(k.substring(0, i));
            }
            if (n > 0) AppIconView.drawBadge(c, left + size - 3 * density, top + 3 * density, n, badgeMode == 2, badge, badgeText, density);
        }
    }
}
