package com.prism.launcher;

import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.HapticFeedbackConstants;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;

/**
 * Pick up an icon / widget and put it somewhere else. The item follows the finger, the cell it would land in
 * lights up, dragging to a screen edge flips pages, and the top strip is Remove / App info / Uninstall.
 */
public class DragController {
    private static final int T_NONE = 0, T_BAR = 1, T_DOCK = 2, T_HOME = 3;

    private final LauncherActivity a;
    private final FrameLayout layer;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final int slop;
    private final float dp;
    private final int[] loc = new int[2];

    private boolean active, moved;
    private ItemInfo item;
    private AppInfo app;
    private int source;
    private View src, shadow, popup;
    private float grabX, grabY, startX, startY;

    private final LinearLayout bar;
    private final TextView[] btns = new TextView[3];
    private final List<TextView> shownBtns = new ArrayList<TextView>();
    private int target, barIdx = -1, tPage, tx, ty;
    private boolean valid;
    private ItemInfo mergeTarget;
    private int edgeDir;
    private boolean needCancel;

    /** True once after a drag starts: the activity then cancels the touch the pressed view still holds. */
    public boolean takeCancel() {
        boolean b = needCancel;
        needCancel = false;
        return b;
    }

    private final Runnable edgeRun = new Runnable() {
        @Override public void run() {
            if (!active || edgeDir == 0) return;
            int cur = a.pager.getCurrentItem(), n = a.model.pageCount();
            if (edgeDir < 0 && cur > 0) {
                a.pager.setCurrentItem(cur - 1, true);
            } else if (edgeDir > 0) {
                if (cur < n - 1) a.pager.setCurrentItem(cur + 1, true);
                else if (n < 6) a.addPage();
            }
            h.postDelayed(this, 900);
        }
    };

    public DragController(LauncherActivity act, FrameLayout layer) {
        a = act;
        this.layer = layer;
        slop = ViewConfiguration.get(act).getScaledTouchSlop();
        dp = act.getResources().getDisplayMetrics().density;

        bar = new LinearLayout(act);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER);
        bar.setVisibility(View.GONE);
        int[] icons = {R.drawable.ic_delete, R.drawable.ic_info, R.drawable.ic_close};
        int[] labels = {R.string.remove, R.string.app_info, R.string.uninstall};
        for (int i = 0; i < 3; i++) {
            TextView t = new TextView(act);
            t.setText(labels[i]);
            t.setTextColor(0xFFFFFFFF);
            t.setTextSize(13);
            t.setGravity(Gravity.CENTER);
            t.setCompoundDrawablesWithIntrinsicBounds(0, icons[i], 0, 0);
            t.setCompoundDrawablePadding(Util.dp(act, 4));
            t.setPadding(0, Util.dp(act, 10), 0, Util.dp(act, 10));
            btns[i] = t;
        }
        layer.addView(bar, new FrameLayout.LayoutParams(-1, Util.dp(act, 96), Gravity.TOP));
    }

    public boolean isActive() { return active; }

    /** Start a drag. The popup (app shortcuts) shows right away and goes away as soon as the finger moves. */
    public void begin(ItemInfo it, AppInfo ap, View view, int source, float rx, float ry) {
        if (active) return;
        active = true;
        needCancel = true;
        moved = false;
        item = it;
        app = ap;
        src = view;
        this.source = source;
        startX = rx;
        startY = ry;
        a.pager.setUserInputEnabled(false);
        layer.getLocationOnScreen(loc);

        int w, hgt;
        if (it.type == ItemInfo.APP) {
            w = hgt = Math.round(Util.dp(a, a.prefs.iconDp()) * 1.12f);
            ImageView iv = new ImageView(a);
            if (view instanceof AppIconView && ((AppIconView) view).icon != null) iv.setImageBitmap(((AppIconView) view).icon);
            iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
            shadow = iv;
            grabX = w / 2f;
            grabY = hgt / 2f;
        } else {
            w = Math.max(Util.dp(a, 90), view.getWidth());
            hgt = Math.max(Util.dp(a, 70), view.getHeight());
            GlassView g = new GlassView(a);
            g.setRadiusDp(26);
            g.setStrength(2.2f);
            shadow = g;
            int[] vl = new int[2];
            view.getLocationOnScreen(vl);
            grabX = Math.max(0, Math.min(w, rx - vl[0]));
            grabY = Math.max(0, Math.min(hgt, ry - vl[1]));
        }
        shadow.setVisibility(View.INVISIBLE);
        layer.addView(shadow, new FrameLayout.LayoutParams(w, hgt));
        place(rx, ry);

        // the popup for this item
        if (it.type == ItemInfo.APP && ap != null) popup = ShortcutPopup.forApp(a, ap, it, source);
        else if (it.type == ItemInfo.WIDGET) popup = ShortcutPopup.forWidget(a, it);
        if (popup != null && view != null) a.showPopup(popup, view);
        a.vibrate();
    }

    public boolean handle(MotionEvent ev) {
        float x = ev.getRawX(), y = ev.getRawY();
        switch (ev.getActionMasked()) {
            case MotionEvent.ACTION_MOVE:
                if (!moved && Math.hypot(x - startX, y - startY) > slop * 1.5f) {
                    moved = true;
                    onFirstMove();
                }
                if (moved) {
                    place(x, y);
                    updateTarget(x, y);
                }
                break;
            case MotionEvent.ACTION_UP:
                end(true);
                break;
            case MotionEvent.ACTION_CANCEL:
                end(false);
                break;
        }
        return true;
    }

    private void onFirstMove() {
        a.dismissPopup();
        popup = null;
        if (src != null && source != ShortcutPopup.DRAWER) src.setVisibility(View.INVISIBLE);
        if (source == ShortcutPopup.DRAWER) a.closeDrawer(true);
        shadow.setVisibility(View.VISIBLE);
        shadow.setScaleX(0.8f);
        shadow.setScaleY(0.8f);
        shadow.animate().scaleX(1.1f).scaleY(1.1f).setDuration(160).start();

        shownBtns.clear();
        bar.removeAllViews();
        boolean appItem = item.type == ItemInfo.APP;
        if (source != ShortcutPopup.DRAWER) shownBtns.add(btns[0]);
        if (appItem) {
            shownBtns.add(btns[1]);
            if (app != null && !app.system) shownBtns.add(btns[2]);
        }
        for (TextView t : shownBtns) {
            t.setBackground(null);
            bar.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
        }
        bar.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[] {0xCC000000, 0x00000000}));
        bar.setPadding(0, a.insetTop, 0, 0);
        bar.getLayoutParams().height = Util.dp(a, 96) + a.insetTop;
        bar.requestLayout();
        bar.setAlpha(0f);
        bar.setVisibility(View.VISIBLE);
        bar.animate().alpha(1f).setDuration(160).start();
        a.vibrate();
    }

    private void place(float x, float y) {
        layer.getLocationOnScreen(loc);
        shadow.setX(x - loc[0] - grabX);
        shadow.setY(y - loc[1] - grabY);
    }

    private void highlight(CellLayout cl, boolean on, int cx, int cy, int sx, int sy, boolean ok) {
        if (cl != null) cl.setHighlight(on, cx, cy, sx, sy, ok);
    }

    private void clearHighlights() {
        highlight(a.dockGrid, false, 0, 0, 1, 1, true);
        for (int i = 0; i < a.cells.size(); i++) highlight(a.cells.valueAt(i), false, 0, 0, 1, 1, true);
    }

    private void updateTarget(float x, float y) {
        clearHighlights();
        target = T_NONE;
        valid = false;
        mergeTarget = null;
        layer.getLocationOnScreen(loc);
        float screenW = layer.getWidth();

        // top strip
        if (y - loc[1] < Util.dp(a, 96) + a.insetTop) {
            target = T_BAR;
            int n = shownBtns.size();
            barIdx = n == 0 ? -1 : Math.max(0, Math.min(n - 1, (int) ((x - loc[0]) / (screenW / n))));
            for (int i = 0; i < n; i++) {
                shownBtns.get(i).setBackgroundColor(i == barIdx ? 0x44FFFFFF : 0);
            }
            valid = barIdx >= 0;
            edge(0);
            return;
        }
        for (TextView t : shownBtns) t.setBackground(null);

        ItemInfo ignore = source == ShortcutPopup.DRAWER ? null : item;
        int[] dl = new int[2];
        a.dock.getLocationOnScreen(dl);
        if (y > dl[1] - Util.dp(a, 14) && y < dl[1] + a.dock.getHeight() + Util.dp(a, 30)) {
            target = T_DOCK;
            a.dockGrid.getLocationOnScreen(dl);
            tx = a.dockGrid.cellXAt(x - dl[0]);
            ty = 0;
            valid = (item.type == ItemInfo.APP || item.type == ItemInfo.FOLDER) && a.model.isFree(true, -1, tx, 0, 1, 1, ignore);
            if (!valid && item.type == ItemInfo.APP) {
                ItemInfo o = a.model.itemAt(true, -1, tx, 0, ignore);
                if (o != null && (o.type == ItemInfo.APP || o.type == ItemInfo.FOLDER)) {
                    mergeTarget = o;
                    valid = true;
                }
            }
            highlight(a.dockGrid, true, tx, 0, 1, 1, valid);
            edge(0);
            return;
        }

        CellLayout cl = a.cells.get(a.pager.getCurrentItem());
        if (cl == null) return;
        int[] cll = new int[2];
        cl.getLocationOnScreen(cll);
        target = T_HOME;
        tPage = a.pager.getCurrentItem();
        int sx = item.type == ItemInfo.APP ? 1 : item.sx, sy = item.type == ItemInfo.APP ? 1 : item.sy;
        tx = Math.min(cl.cellXAt(x - cll[0] - (sx - 1) * cl.cellW() / 2f), cl.cols() - sx);
        ty = Math.min(cl.cellYAt(y - cll[1] - (sy - 1) * cl.cellH() / 2f), cl.rows() - sy);
        tx = Math.max(0, tx);
        ty = Math.max(0, ty);
        valid = a.model.isFree(false, tPage, tx, ty, sx, sy, ignore);
        if (!valid && item.type == ItemInfo.APP) {
            ItemInfo o = a.model.itemAt(false, tPage, tx, ty, ignore);
            if (o != null && (o.type == ItemInfo.APP || o.type == ItemInfo.FOLDER)) {
                mergeTarget = o;
                valid = true;
            }
        }
        highlight(cl, true, tx, ty, sx, sy, valid);

        // screen edges flip pages
        if (x < 26 * dp) edge(-1);
        else if (x > screenW - 26 * dp) edge(1);
        else edge(0);
    }

    private void edge(int dir) {
        if (dir == edgeDir) return;
        edgeDir = dir;
        h.removeCallbacks(edgeRun);
        if (dir != 0) h.postDelayed(edgeRun, 650);
    }

    private void end(boolean drop) {
        h.removeCallbacks(edgeRun);
        active = false;
        edgeDir = 0;
        layer.removeView(shadow);
        shadow = null;
        a.pager.setUserInputEnabled(true);

        if (!moved) {
            // a plain long-press: the popup stays open, nothing was dragged
            popup = null;
            return;
        }
        clearHighlights();
        bar.animate().alpha(0f).setDuration(120).withEndAction(() -> bar.setVisibility(View.GONE)).start();

        if (drop && valid) {
            if (target == T_BAR) {
                int idx = barIdx;
                TextView t = idx >= 0 && idx < shownBtns.size() ? shownBtns.get(idx) : null;
                if (t == btns[0]) a.removeItem(item);
                else if (t == btns[1] && app != null) a.openAppInfo(app);
                else if (t == btns[2] && app != null) a.uninstall(app);
            } else if ((target == T_DOCK || target == T_HOME) && mergeTarget != null && app != null) {
                a.mergeInto(mergeTarget, item, app, source == ShortcutPopup.DRAWER);
            } else if (target == T_DOCK || target == T_HOME) {
                ItemInfo it = item;
                if (source == ShortcutPopup.DRAWER) {
                    it = new ItemInfo();
                    it.type = ItemInfo.APP;
                    it.comp = app.key;
                    a.model.add(it);
                }
                if (target == T_DOCK) {
                    it.dock = true; it.page = -1; it.cx = tx; it.cy = 0; it.sx = 1; it.sy = 1;
                } else {
                    it.dock = false; it.page = tPage; it.cx = tx; it.cy = ty;
                }
                a.model.save();
            }
        }
        a.model.trimPages();
        a.finishDrag();
    }
}
