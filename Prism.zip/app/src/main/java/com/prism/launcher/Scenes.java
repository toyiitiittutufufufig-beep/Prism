package com.prism.launcher;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.net.Uri;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Random;

/** The animated backgrounds. Used by the launcher and by the live wallpaper service. */
public class Scenes {
    public static final int AURORA = 0, WAVES = 1, BOKEH = 2, STARS = 3, GRADIENT = 4, PHOTO = 5, SYSTEM = 6;
    public static final String[] NAMES = {"Aurora", "Waves", "Bokeh", "Stars", "Gradient", "My photo", "System wallpaper"};

    private static final Paint P = new Paint(Paint.ANTI_ALIAS_FLAG);
    private static final Path PATH = new Path();
    private static final float[][] BOK = new float[22][6];
    private static final float[][] STAR = new float[110][5];
    private static Bitmap photoCache;
    private static long photoStamp = -1;

    static {
        Random r = new Random(7);
        for (float[] b : BOK) {
            b[0] = r.nextFloat(); b[1] = r.nextFloat(); b[2] = 0.05f + r.nextFloat() * 0.11f;
            b[3] = 0.4f + r.nextFloat() * 1.2f; b[4] = r.nextFloat() * 6.28f; b[5] = r.nextInt(3);
        }
        for (float[] s : STAR) {
            s[0] = r.nextFloat(); s[1] = r.nextFloat(); s[2] = 0.6f + r.nextFloat() * 1.6f;
            s[3] = 0.3f + r.nextFloat() * 1.2f; s[4] = r.nextFloat() * 6.28f;
        }
    }

    public static boolean animated(int style) { return style != SYSTEM && style != PHOTO; }

    public static void draw(Canvas c, int w, int h, long ms, int style, Themes.T th, float scroll, Bitmap photo) {
        if (style == SYSTEM) {
            scrim(c, w, h, 0x38);
            return;
        }
        if (style == PHOTO && photo != null) {
            drawPhoto(c, w, h, scroll, photo);
            scrim(c, w, h, 0x40);
            return;
        }
        if (style == PHOTO) style = AURORA;
        int[] pal = th.pal;
        float t = ms / 1000f;
        base(c, w, h, pal[0], pal[1]);
        float sh = -scroll * w * 0.06f;
        switch (style) {
            case WAVES: {
                blob(c, w * 0.3f + sh, h * 0.14f, w * 0.95f, pal[3], 0x66);
                for (int i = 0; i < 3; i++) {
                    PATH.reset();
                    PATH.moveTo(0, h);
                    float step = w / 28f;
                    for (float x = 0; x <= w + step; x += step) {
                        float u = x / w;
                        float y = h * (0.52f + 0.1f * i)
                                + h * 0.035f * (float) Math.sin(u * (5f + i * 2f) + t * (0.55f + 0.25f * i) + i * 1.7f + scroll)
                                + h * 0.018f * (float) Math.sin(u * 11f - t * 0.9f + i);
                        PATH.lineTo(x, y);
                    }
                    PATH.lineTo(w + step, h);
                    PATH.close();
                    P.setColor(Util.withAlpha(pal[2 + i], 0x70 - i * 0x14));
                    c.drawPath(PATH, P);
                }
                break;
            }
            case BOKEH: {
                float m = Math.min(w, h);
                for (float[] b : BOK) {
                    float yy = (((b[1] - t * b[3] * 0.012f) % 1f) + 1f) % 1f;
                    float x = b[0] * w + (float) Math.sin(t * 0.3f + b[4]) * w * 0.03f + sh * b[2] * 6f;
                    float y = yy * (h * 1.2f) - h * 0.1f;
                    float a = 0x50 + 0x38 * (float) Math.sin(t * 0.8f * b[3] + b[4]);
                    blob(c, x, y, b[2] * m * 1.5f, pal[2 + (int) b[5]], (int) a);
                }
                break;
            }
            case STARS: {
                blob(c, w * 0.2f + sh, h * 0.25f, w * 0.9f, pal[3], 0x44);
                blob(c, w * 0.85f + sh, h * 0.7f, w * 0.8f, pal[4], 0x38);
                float k = w / 1080f;
                for (float[] s : STAR) {
                    float x = (((s[0] + scroll * s[3] * 0.06f + t * 0.0015f * s[3]) % 1f) + 1f) % 1f * w;
                    float y = (((s[1] + t * 0.004f * s[3]) % 1f) + 1f) % 1f * h;
                    int a = (int) (60 + 195 * Math.abs(Math.sin(t * (0.5f + s[3]) + s[4])));
                    P.setColor(Util.withAlpha(0xFFFFFFFF, a));
                    c.drawCircle(x, y, s[2] * s[3] * 1.4f * k + 0.6f, P);
                }
                break;
            }
            case GRADIENT: {
                float a = t * 0.12f;
                float dx = (float) Math.cos(a) * w, dy = (float) Math.sin(a) * h;
                P.setShader(new LinearGradient(w / 2f - dx, h / 2f - dy, w / 2f + dx, h / 2f + dy,
                        new int[] {Util.withAlpha(pal[2], 0xE0), Util.withAlpha(pal[3], 0xE0), Util.withAlpha(pal[4], 0xE0)},
                        null, Shader.TileMode.CLAMP));
                c.drawRect(0, 0, w, h, P);
                P.setShader(null);
                break;
            }
            default: {   // AURORA
                float m = Math.max(w, h);
                for (int i = 0; i < 5; i++) {
                    float cx = w * (0.5f + 0.42f * (float) Math.sin(t * 0.17f * (i + 1) + i * 1.7f)) + sh * (1 + i * 0.3f);
                    float cy = h * (0.5f + 0.38f * (float) Math.cos(t * 0.13f * (i + 1) + i * 2.3f));
                    float r = m * (0.42f + 0.1f * (float) Math.sin(t * 0.2f + i));
                    blob(c, cx, cy, r, pal[2 + i % 3], 0x90);
                }
            }
        }
        scrim(c, w, h, 0x22);
    }

    private static void base(Canvas c, int w, int h, int a, int b) {
        P.setShader(new LinearGradient(0, 0, 0, h, a, b, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, w, h, P);
        P.setShader(null);
    }

    private static void blob(Canvas c, float cx, float cy, float r, int color, int alpha) {
        if (r <= 0) return;
        P.setShader(new RadialGradient(cx, cy, r, new int[] {Util.withAlpha(color, alpha), Util.withAlpha(color, 0)},
                null, Shader.TileMode.CLAMP));
        c.drawCircle(cx, cy, r, P);
        P.setShader(null);
    }

    /** Darkens a little (more at the bottom) so icon names stay readable. */
    private static void scrim(Canvas c, int w, int h, int bottomAlpha) {
        P.setShader(new LinearGradient(0, 0, 0, h, Util.withAlpha(0, bottomAlpha / 3), Util.withAlpha(0, bottomAlpha),
                Shader.TileMode.CLAMP));
        c.drawRect(0, 0, w, h, P);
        P.setShader(null);
    }

    private static void drawPhoto(Canvas c, int w, int h, float scroll, Bitmap b) {
        float s = Math.max(h / (float) b.getHeight(), w * 1.12f / b.getWidth());
        float extra = b.getWidth() * s - w;
        float shift = Math.max(-extra / 2f, Math.min(extra / 2f, -scroll * w * 0.06f));
        c.save();
        c.translate((w - b.getWidth() * s) / 2f + shift, (h - b.getHeight() * s) / 2f);
        c.scale(s, s);
        P.setFilterBitmap(true);
        c.drawBitmap(b, 0, 0, P);
        P.setFilterBitmap(false);
        c.restore();
    }

    // ------------------------------------------------------------ user photo

    private static File photoFile(Context c) { return new File(c.getFilesDir(), "wallpaper.img"); }

    public static boolean savePhoto(Context c, Uri uri) {
        try (InputStream in = c.getContentResolver().openInputStream(uri);
             OutputStream out = new FileOutputStream(photoFile(c))) {
            byte[] buf = new byte[16384];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            photoStamp = -1;
            return true;
        } catch (Throwable e) {
            return false;
        }
    }

    public static synchronized Bitmap loadPhoto(Context c) {
        File f = photoFile(c);
        if (!f.exists()) return null;
        if (photoCache != null && photoStamp == f.lastModified()) return photoCache;
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(f.getPath(), o);
            int s = 1;
            while (Math.max(o.outWidth, o.outHeight) / (s * 2) >= 1800) s *= 2;
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = s;
            photoCache = BitmapFactory.decodeFile(f.getPath(), o2);
            photoStamp = f.lastModified();
            return photoCache;
        } catch (Throwable e) {
            return null;
        }
    }
}
