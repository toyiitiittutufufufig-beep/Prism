package com.prism.launcher;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.provider.MediaStore;
import android.provider.Settings;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import org.json.JSONArray;

/** What is placed where. Saved as JSON after every change. */
public class Model {
    private final Context ctx;
    private final Prefs prefs;
    public final List<ItemInfo> items = new ArrayList<ItemInfo>();
    private long nextId = 1;

    public Model(Context c) {
        ctx = c.getApplicationContext();
        prefs = Prefs.get(c);
        load();
    }

    public void reload() { load(); }

    private void load() {
        items.clear();
        try {
            JSONArray a = new JSONArray(prefs.s(Prefs.ITEMS, "[]"));
            for (int i = 0; i < a.length(); i++) {
                ItemInfo it = ItemInfo.fromJson(a.getJSONObject(i));
                items.add(it);
                nextId = Math.max(nextId, it.id + 1);
            }
        } catch (Throwable ignored) { }
    }

    public void save() {
        try {
            JSONArray a = new JSONArray();
            for (ItemInfo i : items) a.put(i.toJson());
            prefs.put(Prefs.ITEMS, a.toString());
        } catch (Throwable ignored) { }
    }

    public int pageCount() { return Math.max(1, prefs.i(Prefs.PAGES, 1)); }
    public void setPageCount(int n) { prefs.put(Prefs.PAGES, Math.max(1, n)); }

    public List<ItemInfo> page(int p) {
        List<ItemInfo> out = new ArrayList<ItemInfo>();
        for (ItemInfo i : items) if (!i.dock && i.page == p) out.add(i);
        return out;
    }

    public List<ItemInfo> dock() {
        List<ItemInfo> out = new ArrayList<ItemInfo>();
        for (ItemInfo i : items) if (i.dock) out.add(i);
        Collections.sort(out, new Comparator<ItemInfo>() {
            @Override public int compare(ItemInfo a, ItemInfo b) { return a.cx - b.cx; }
        });
        return out;
    }

    public ItemInfo add(ItemInfo i) {
        i.id = nextId++;
        items.add(i);
        return i;
    }

    public void remove(ItemInfo i) { items.remove(i); }

    /** Is the rectangle free on that page (or in the dock when page < 0)? */
    public boolean isFree(boolean dock, int page, int cx, int cy, int sx, int sy, ItemInfo ignore) {
        int cols = dock ? prefs.dockCount() : prefs.cols();
        int rows = dock ? 1 : prefs.rows();
        if (cx < 0 || cy < 0 || cx + sx > cols || cy + sy > rows) return false;
        for (ItemInfo o : items) {
            if (o == ignore || o.dock != dock || (!dock && o.page != page)) continue;
            if (cx < o.cx + o.sx && o.cx < cx + sx && cy < o.cy + o.sy && o.cy < cy + sy) return false;
        }
        return true;
    }

    /** The item covering a cell, if any. */
    public ItemInfo itemAt(boolean dock, int page, int cx, int cy, ItemInfo ignore) {
        for (ItemInfo o : items) {
            if (o == ignore || o.dock != dock || (!dock && o.page != page)) continue;
            if (cx >= o.cx && cx < o.cx + o.sx && cy >= o.cy && cy < o.cy + o.sy) return o;
        }
        return null;
    }

    /** After a restore: forget widgets whose ids don't exist on this device. */
    public void dropDeadWidgets() {
        android.appwidget.AppWidgetManager awm = android.appwidget.AppWidgetManager.getInstance(ctx);
        boolean changed = false;
        for (ItemInfo i : new ArrayList<ItemInfo>(items)) {
            if (i.type == ItemInfo.WIDGET && awm.getAppWidgetInfo(i.widgetId) == null) {
                items.remove(i);
                changed = true;
            }
        }
        if (changed) save();
    }

    /** First free spot, scanning rows from the top. Null if the page is full. */
    public int[] findSpot(int page, int sx, int sy) {
        int cols = prefs.cols(), rows = prefs.rows();
        for (int y = 0; y + sy <= rows; y++)
            for (int x = 0; x + sx <= cols; x++)
                if (isFree(false, page, x, y, sx, sy, null)) return new int[] {x, y};
        return null;
    }

    /** Drops apps that were uninstalled and clamps anything that no longer fits the grid. */
    public boolean prune(AppRepo repo) {
        boolean changed = false;
        int cols = prefs.cols(), rows = prefs.rows(), dc = prefs.dockCount();
        List<ItemInfo> gone = new ArrayList<ItemInfo>();
        for (ItemInfo i : items) {
            if (i.type == ItemInfo.APP && repo.find(i.comp) == null) gone.add(i);
        }
        if (!gone.isEmpty()) {
            items.removeAll(gone);
            changed = true;
        }
        for (ItemInfo f : new ArrayList<ItemInfo>(items)) {
            if (f.type != ItemInfo.FOLDER) continue;
            int before = f.apps.size();
            List<String> keep = new ArrayList<String>();
            for (String k : f.apps) if (repo.find(k) != null) keep.add(k);
            f.apps = keep;
            if (keep.size() <= 1) {
                if (keep.size() == 1) {
                    f.type = ItemInfo.APP;
                    f.comp = keep.get(0);
                    f.apps = new ArrayList<String>();
                } else {
                    items.remove(f);
                }
                changed = true;
            } else if (keep.size() != before) {
                changed = true;
            }
        }
        List<ItemInfo> lost = new ArrayList<ItemInfo>();
        for (ItemInfo i : new ArrayList<ItemInfo>(items)) {
            boolean ok = i.dock ? (i.cx < dc) : (i.cx + i.sx <= cols && i.cy + i.sy <= rows);
            if (ok) continue;
            items.remove(i);
            lost.add(i);
            changed = true;
        }
        for (ItemInfo i : lost) {   // re-place what fell off the grid on the first page with room
            i.dock = false;
            i.sx = Math.min(i.sx, cols);
            i.sy = Math.min(i.sy, rows);
            boolean placed = false;
            for (int p = 0; p < pageCount() && !placed; p++) {
                int[] s = findSpot(p, i.sx, i.sy);
                if (s != null) {
                    i.page = p; i.cx = s[0]; i.cy = s[1];
                    items.add(i);
                    placed = true;
                }
            }
        }
        // overlapping leftovers (grid got smaller): push to a free spot
        if (changed) save();
        return changed;
    }

    /** Removes empty pages except the first. Returns true if the count changed. */
    public boolean trimPages() {
        int n = pageCount();
        boolean changed = false;
        for (int p = n - 1; p > 0; p--) {
            if (page(p).isEmpty()) {
                n--;
                changed = true;
            } else break;
        }
        if (changed) setPageCount(n);
        return changed;
    }

    // ------------------------------------------------------------ first run

    public void ensureDefaults(AppRepo repo) {
        if (prefs.b(Prefs.INIT, false) && !items.isEmpty()) return;
        items.clear();
        int dc = prefs.dockCount(), cols = prefs.cols();
        List<String> used = new ArrayList<String>();

        List<ComponentName> dock = new ArrayList<ComponentName>();
        dock.add(resolve(new Intent(Intent.ACTION_DIAL), repo));
        dock.add(resolve(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MESSAGING), repo));
        dock.add(resolve(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_BROWSER), repo));
        dock.add(resolve(new Intent(MediaStore.ACTION_IMAGE_CAPTURE), repo));
        dock.add(resolve(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MUSIC), repo));
        int d = 0;
        for (ComponentName cn : dock) {
            if (cn == null || used.contains(cn.flattenToString()) || d >= dc) continue;
            ItemInfo it = new ItemInfo();
            it.type = ItemInfo.APP; it.comp = cn.flattenToString(); it.dock = true; it.cx = d++; it.page = -1;
            add(it);
            used.add(it.comp);
        }

        ItemInfo clock = new ItemInfo();
        clock.type = ItemInfo.CLOCK; clock.page = 0; clock.cx = 0; clock.cy = 0; clock.sx = cols; clock.sy = 2;
        add(clock);

        List<ComponentName> home = new ArrayList<ComponentName>();
        String[] cats = {Intent.CATEGORY_APP_GALLERY, Intent.CATEGORY_APP_MAPS, Intent.CATEGORY_APP_EMAIL,
                Intent.CATEGORY_APP_CALENDAR, Intent.CATEGORY_APP_CALCULATOR, Intent.CATEGORY_APP_CONTACTS};
        for (String cat : cats) home.add(resolve(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, cat), repo));
        home.add(resolve(new Intent(Settings.ACTION_SETTINGS), repo));
        int x = 0, y = 2;
        for (ComponentName cn : home) {
            if (cn == null || used.contains(cn.flattenToString())) continue;
            if (y >= prefs.rows()) break;
            ItemInfo it = new ItemInfo();
            it.type = ItemInfo.APP; it.comp = cn.flattenToString(); it.page = 0; it.cx = x; it.cy = y;
            add(it);
            used.add(it.comp);
            if (++x >= cols) { x = 0; y++; }
        }
        prefs.put(Prefs.PAGES, 1);
        prefs.put(Prefs.INIT, true);
        save();
    }

    private ComponentName resolve(Intent i, AppRepo repo) {
        try {
            ResolveInfo ri = ctx.getPackageManager().resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY);
            if (ri == null || ri.activityInfo == null || "android".equals(ri.activityInfo.packageName)) return null;
            ComponentName cn = new ComponentName(ri.activityInfo.packageName, ri.activityInfo.name);
            if (repo.find(cn) != null) return cn;
            // the resolved activity might not be the launcher entry: use that package's launcher activity
            for (AppInfo a : repo.all()) if (a.comp.getPackageName().equals(cn.getPackageName())) return a.comp;
        } catch (Throwable ignored) { }
        return null;
    }
}
