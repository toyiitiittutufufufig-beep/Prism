package com.prism.launcher;

import android.content.Context;
import android.content.pm.LauncherApps;
import android.content.pm.ShortcutInfo;
import android.graphics.drawable.Drawable;
import android.os.Process;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;

/** The little glass menu that opens when you long-press an icon. */
public class ShortcutPopup {
    public static final int HOME = 0, DOCK = 1, DRAWER = 2;

    public static View forApp(final LauncherActivity a, final AppInfo app, final ItemInfo it, int source) {
        Context c = a;
        GlassView card = card(c);
        LinearLayout col = new LinearLayout(c);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(0, Util.dp(c, 6), 0, Util.dp(c, 6));

        // the app's own shortcuts (compose message, new tab, ...). Works because Prism is the home app.
        try {
            final LauncherApps la = (LauncherApps) c.getSystemService(Context.LAUNCHER_APPS_SERVICE);
            LauncherApps.ShortcutQuery q = new LauncherApps.ShortcutQuery();
            q.setPackage(app.comp.getPackageName());
            q.setQueryFlags(LauncherApps.ShortcutQuery.FLAG_MATCH_DYNAMIC | LauncherApps.ShortcutQuery.FLAG_MATCH_MANIFEST
                    | LauncherApps.ShortcutQuery.FLAG_MATCH_PINNED);
            List<ShortcutInfo> list = la.getShortcuts(q, app.user);
            List<ShortcutInfo> ok = new ArrayList<ShortcutInfo>();
            if (list != null) {
                for (ShortcutInfo s : list) {
                    if (!s.isEnabled() || s.getShortLabel() == null) continue;
                    if (s.getActivity() != null && !s.getActivity().equals(app.comp)) continue;
                    ok.add(s);
                    if (ok.size() >= 4) break;
                }
            }
            int dpi = c.getResources().getDisplayMetrics().densityDpi;
            for (final ShortcutInfo s : ok) {
                TextView r = row(c, 0, s.getShortLabel().toString(), () -> {
                    a.dismissPopup();
                    try { la.startShortcut(s, null, null); } catch (Throwable ignored) { }
                });
                Drawable d = la.getShortcutIconDrawable(s, dpi);
                if (d != null) {
                    int sz = Util.dp(c, 22);
                    d.setBounds(0, 0, sz, sz);
                    r.setCompoundDrawablesRelative(d, null, null, null);
                }
                col.addView(r);
            }
            if (!ok.isEmpty()) col.addView(divider(c));
        } catch (Throwable ignored) { }

        if (source == DRAWER) {
            col.addView(row(c, R.drawable.ic_add, c.getString(R.string.add_to_home), () -> { a.dismissPopup(); a.addToHome(app); }));
            col.addView(row(c, R.drawable.ic_close, c.getString(R.string.hide_app), () -> { a.dismissPopup(); a.hideApp(app); }));
        } else if (!Prefs.get(c).b(Prefs.LOCK, false)) {
            col.addView(row(c, R.drawable.ic_delete, c.getString(R.string.remove), () -> { a.dismissPopup(); a.removeItem(it); }));
        }
        col.addView(row(c, R.drawable.ic_brush, c.getString(R.string.rename), () -> { a.dismissPopup(); a.renameApp(app); }));
        col.addView(row(c, R.drawable.ic_info, c.getString(R.string.app_info), () -> { a.dismissPopup(); a.openAppInfo(app); }));
        if (source == DRAWER && !app.system) {
            col.addView(row(c, R.drawable.ic_delete, c.getString(R.string.uninstall), () -> { a.dismissPopup(); a.uninstall(app); }));
        }
        card.addView(col);
        return card;
    }

    public static View forWidget(final LauncherActivity a, final ItemInfo it) {
        Context c = a;
        GlassView card = card(c);
        LinearLayout col = new LinearLayout(c);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(0, Util.dp(c, 6), 0, Util.dp(c, 6));
        col.addView(row(c, R.drawable.ic_add, c.getString(R.string.wider), () -> a.resizeWidget(it, 1, 0)));
        col.addView(row(c, R.drawable.ic_close, c.getString(R.string.narrower), () -> a.resizeWidget(it, -1, 0)));
        col.addView(row(c, R.drawable.ic_add, c.getString(R.string.taller), () -> a.resizeWidget(it, 0, 1)));
        col.addView(row(c, R.drawable.ic_close, c.getString(R.string.shorter), () -> a.resizeWidget(it, 0, -1)));
        col.addView(divider(c));
        col.addView(row(c, R.drawable.ic_delete, c.getString(R.string.remove), () -> { a.dismissPopup(); a.removeItem(it); }));
        card.addView(col);
        return card;
    }

    private static GlassView card(Context c) {
        GlassView g = new GlassView(c);
        g.setRadiusDp(22);
        g.setTint(0x101830);
        return g;
    }

    private static View divider(Context c) {
        View v = new View(c);
        v.setBackgroundColor(0x22FFFFFF);
        v.setLayoutParams(new LinearLayout.LayoutParams(-1, Util.dp(c, 1)));
        return v;
    }

    private static TextView row(Context c, int icon, String label, final Runnable r) {
        final TextView t = new TextView(c);
        t.setText(label);
        t.setTextColor(0xFFFFFFFF);
        t.setTextSize(15);
        t.setSingleLine(true);
        t.setGravity(Gravity.CENTER_VERTICAL);
        t.setMinWidth(Util.dp(c, 200));
        t.setMinHeight(Util.dp(c, 48));
        t.setPadding(Util.dp(c, 18), Util.dp(c, 6), Util.dp(c, 22), Util.dp(c, 6));
        t.setCompoundDrawablePadding(Util.dp(c, 14));
        if (icon != 0) t.setCompoundDrawablesRelativeWithIntrinsicBounds(icon, 0, 0, 0);
        t.setClickable(true);
        t.setOnClickListener(v -> r.run());
        t.setOnTouchListener((v, e) -> {
            int a = e.getActionMasked();
            t.setAlpha(a == MotionEvent.ACTION_DOWN || a == MotionEvent.ACTION_MOVE ? 0.6f : 1f);
            return false;
        });
        return t;
    }
}
