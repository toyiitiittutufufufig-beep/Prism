package com.prism.launcher;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

/** Little glass dots under the pages. */
public class PageIndicator extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF r = new RectF();
    private int count = 1;
    private float pos = 0f;
    private int accent = 0xFFFFFFFF;

    public PageIndicator(Context c) { super(c); }

    public void setCount(int n) { count = Math.max(1, n); requestLayout(); invalidate(); }
    public void setPosition(float f) { pos = f; invalidate(); }
    public void setAccent(int c) { accent = c; invalidate(); }

    @Override
    protected void onMeasure(int w, int h) {
        float d = getResources().getDisplayMetrics().density;
        setMeasuredDimension(Math.round((count * 14 + 14) * d), Math.round(16 * d));
    }

    @Override
    protected void onDraw(Canvas c) {
        float d = getResources().getDisplayMetrics().density;
        float dot = 6 * d, gap = 8 * d;
        float total = count * dot + (count - 1) * gap;
        float x0 = (getWidth() - total) / 2f, cy = getHeight() / 2f;
        for (int i = 0; i < count; i++) {
            float dist = Math.min(1f, Math.abs(i - pos));
            float wd = dot + (1f - dist) * dot * 1.4f;
            float cx = x0 + i * (dot + gap) + dot / 2f;
            p.setColor(dist < 0.5f ? accent : 0x66FFFFFF);
            p.setAlpha((int) (110 + 145 * (1f - dist)));
            r.set(cx - wd / 2f, cy - dot / 2f, cx + wd / 2f, cy + dot / 2f);
            c.drawRoundRect(r, dot / 2f, dot / 2f, p);
        }
    }
}
