package com.prism.launcher;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.ViewConfiguration;

/**
 * Watches touches on the home screen without getting in the way of icons and pages:
 * swipe up (drawer, follows your finger), swipe down, double tap, long-press on empty space,
 * and two-finger swipes up / down. The last four run whatever you picked in settings.
 */
public class GestureTracker {
    public interface Host {
        boolean hitItem(float rawX, float rawY);
        boolean hitWidget(float rawX, float rawY);
        void dragDrawer(float dy);
        void releaseDrawer(float velocityY);
        void action(String id);
        void longPressEmpty();
        void cancelChildren(MotionEvent ev);
    }

    private final Host h;
    private final Context c;
    private final Prefs prefs;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final int slop;
    private final float dp;

    private float x0, y0, twoY0;
    private long t0, lastTap;
    private float lastTx, lastTy;
    private boolean onWidget, onItem, moved, two, consumed, claimedDrawer, claimedDown;
    private VelocityTracker vt;

    private final Runnable longPress = new Runnable() {
        @Override public void run() {
            if (!moved && !two && !consumed) {
                consumed = true;
                h.longPressEmpty();
            }
        }
    };

    public GestureTracker(Context c, Host h) {
        this.c = c;
        this.h = h;
        prefs = Prefs.get(c);
        slop = ViewConfiguration.get(c).getScaledTouchSlop();
        dp = c.getResources().getDisplayMetrics().density;
    }

    public boolean claimed() { return consumed; }

    private float avgY(MotionEvent e) {
        return (e.getY(0) + e.getY(1)) / 2f;
    }

    private void reset() {
        moved = two = consumed = claimedDrawer = claimedDown = false;
        main.removeCallbacks(longPress);
        if (vt != null) {
            vt.recycle();
            vt = null;
        }
    }

    /** Returns true when the gesture is ours and the views underneath should not see it. */
    public boolean onTouch(MotionEvent ev) {
        int a = ev.getActionMasked();
        if (vt != null) vt.addMovement(ev);
        switch (a) {
            case MotionEvent.ACTION_DOWN:
                reset();
                x0 = ev.getRawX();
                y0 = ev.getRawY();
                t0 = ev.getEventTime();
                onWidget = h.hitWidget(x0, y0);
                onItem = h.hitItem(x0, y0);
                vt = VelocityTracker.obtain();
                vt.addMovement(ev);
                if (!onItem && !onWidget) main.postDelayed(longPress, ViewConfiguration.getLongPressTimeout());
                return false;

            case MotionEvent.ACTION_POINTER_DOWN:
                if (!consumed && ev.getPointerCount() == 2) {
                    two = true;
                    twoY0 = avgY(ev);
                    main.removeCallbacks(longPress);
                }
                return consumed;

            case MotionEvent.ACTION_MOVE: {
                if (consumed) {
                    if (claimedDrawer) h.dragDrawer(ev.getRawY() - y0);
                    return true;
                }
                if (two) {
                    if (ev.getPointerCount() >= 2) {
                        float dy = avgY(ev) - twoY0;
                        if (Math.abs(dy) > 48 * dp) {
                            consumed = true;
                            h.cancelChildren(ev);
                            h.action(prefs.s(dy < 0 ? Prefs.G_2UP : Prefs.G_2DOWN, dy < 0 ? "search" : "quick_settings"));
                        }
                    }
                    return consumed;
                }
                float dx = ev.getRawX() - x0, dy = ev.getRawY() - y0;
                if (!moved && (Math.abs(dx) > slop || Math.abs(dy) > slop)) {
                    moved = true;
                    main.removeCallbacks(longPress);
                }
                if (!onWidget && Math.abs(dy) > slop * 2 && Math.abs(dy) > Math.abs(dx) * 1.3f) {
                    consumed = true;
                    h.cancelChildren(ev);
                    if (dy < 0) {
                        claimedDrawer = true;
                        h.dragDrawer(dy);
                    } else {
                        claimedDown = true;
                    }
                    return true;
                }
                return false;
            }

            case MotionEvent.ACTION_POINTER_UP:
                return consumed;

            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL: {
                main.removeCallbacks(longPress);
                boolean was = consumed;
                if (claimedDrawer) {
                    float v = 0;
                    if (vt != null) {
                        vt.computeCurrentVelocity(1000);
                        v = vt.getYVelocity();
                    }
                    h.releaseDrawer(v);
                } else if (claimedDown) {
                    if (a == MotionEvent.ACTION_UP && ev.getRawY() - y0 > 70 * dp) {
                        h.action(prefs.s(Prefs.G_DOWN, "notifications"));
                    }
                } else if (!was && !moved && !two && a == MotionEvent.ACTION_UP && !onItem && !onWidget
                        && ev.getEventTime() - t0 < 300) {
                    long now = ev.getEventTime();
                    if (now - lastTap < 320 && Math.abs(ev.getRawX() - lastTx) < 60 * dp && Math.abs(ev.getRawY() - lastTy) < 60 * dp) {
                        lastTap = 0;
                        h.action(prefs.s(Prefs.G_DOUBLE, "lock"));
                    } else {
                        lastTap = now;
                        lastTx = ev.getRawX();
                        lastTy = ev.getRawY();
                    }
                }
                reset();
                return was;
            }
        }
        return consumed;
    }
}
