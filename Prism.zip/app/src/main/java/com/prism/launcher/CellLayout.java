package com.prism.launcher;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;
import android.view.ViewGroup;

/** A fixed grid. Children say which cell(s) they occupy through {@link LP}. */
public class CellLayout extends ViewGroup {
    public static class LP extends ViewGroup.LayoutParams {
        public int cx, cy, sx = 1, sy = 1;
        public LP(int cx, int cy, int sx, int sy) {
            super(WRAP_CONTENT, WRAP_CONTENT);
            this.cx = cx; this.cy = cy; this.sx = sx; this.sy = sy;
        }
        public LP(ViewGroup.LayoutParams src) { super(src); }
    }

    private int cols = 4, rows = 6;
    private float cellW, cellH;
    private int padL, padT, padR, padB;
    private final Paint hl = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF hr = new RectF();
    private boolean hlOn, hlValid;
    private int hcx, hcy, hsx, hsy;

    public CellLayout(Context c) {
        super(c);
        setClipChildren(false);
        setClipToPadding(false);
    }

    public void setGrid(int cols, int rows) {
        this.cols = Math.max(1, cols);
        this.rows = Math.max(1, rows);
        requestLayout();
    }

    public void setCellPadding(int l, int t, int r, int b) {
        padL = l; padT = t; padR = r; padB = b;
        requestLayout();
    }

    public int cols() { return cols; }
    public int rows() { return rows; }
    public float cellW() { return cellW; }
    public float cellH() { return cellH; }

    @Override
    protected void onMeasure(int wSpec, int hSpec) {
        int w = MeasureSpec.getSize(wSpec), h = MeasureSpec.getSize(hSpec);
        setMeasuredDimension(w, h);
        cellW = (w - padL - padR) / (float) cols;
        cellH = (h - padT - padB) / (float) rows;
        for (int i = 0; i < getChildCount(); i++) {
            View v = getChildAt(i);
            LP lp = (LP) v.getLayoutParams();
            v.measure(MeasureSpec.makeMeasureSpec(Math.round(lp.sx * cellW), MeasureSpec.EXACTLY),
                    MeasureSpec.makeMeasureSpec(Math.round(lp.sy * cellH), MeasureSpec.EXACTLY));
        }
    }

    @Override
    protected void onLayout(boolean changed, int l, int t, int r, int b) {
        for (int i = 0; i < getChildCount(); i++) {
            View v = getChildAt(i);
            LP lp = (LP) v.getLayoutParams();
            int x = Math.round(padL + lp.cx * cellW), y = Math.round(padT + lp.cy * cellH);
            v.layout(x, y, x + v.getMeasuredWidth(), y + v.getMeasuredHeight());
        }
    }

    public int cellXAt(float x) { return Math.max(0, Math.min(cols - 1, (int) ((x - padL) / Math.max(1f, cellW)))); }
    public int cellYAt(float y) { return Math.max(0, Math.min(rows - 1, (int) ((y - padT) / Math.max(1f, cellH)))); }

    /** Topmost child under a point in this layout's own coordinates. */
    public View childAt(float x, float y) {
        for (int i = getChildCount() - 1; i >= 0; i--) {
            View v = getChildAt(i);
            if (v.getVisibility() == VISIBLE && x >= v.getLeft() && x <= v.getRight() && y >= v.getTop() && y <= v.getBottom())
                return v;
        }
        return null;
    }

    public void setHighlight(boolean on, int cx, int cy, int sx, int sy, boolean valid) {
        hlOn = on; hcx = cx; hcy = cy; hsx = sx; hsy = sy; hlValid = valid;
        invalidate();
    }

    @Override
    protected void dispatchDraw(Canvas c) {
        if (hlOn) {
            hr.set(padL + hcx * cellW + 6, padT + hcy * cellH + 6, padL + (hcx + hsx) * cellW - 6, padT + (hcy + hsy) * cellH - 6);
            hl.setStyle(Paint.Style.FILL);
            hl.setColor(hlValid ? 0x30FFFFFF : 0x40FF4060);
            float rad = Math.min(hr.width(), hr.height()) * 0.22f;
            c.drawRoundRect(hr, rad, rad, hl);
            hl.setStyle(Paint.Style.STROKE);
            hl.setStrokeWidth(3f);
            hl.setColor(hlValid ? 0x99FFFFFF : 0x99FF4060);
            c.drawRoundRect(hr, rad, rad, hl);
        }
        super.dispatchDraw(c);
    }

    @Override protected boolean checkLayoutParams(ViewGroup.LayoutParams p) { return p instanceof LP; }
    @Override protected ViewGroup.LayoutParams generateDefaultLayoutParams() { return new LP(0, 0, 1, 1); }
    @Override protected ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams p) { return new LP(p); }
}
