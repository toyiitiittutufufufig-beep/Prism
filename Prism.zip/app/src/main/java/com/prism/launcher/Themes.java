package com.prism.launcher;

/** Color themes: drive the animated background, accents and tints. */
public class Themes {
    public static class T {
        public final String name;
        public final int accent;
        /** 0,1 = base gradient (top, bottom); 2,3,4 = glow colors */
        public final int[] pal;
        T(String n, int a, int... p) { name = n; accent = a; pal = p; }
    }

    public static final T[] ALL = {
        new T("Aurora", 0xFF5EE6D0, 0xFF07102B, 0xFF0B1E3F, 0xFF2DD4BF, 0xFF6366F1, 0xFFEC4899),
        new T("Neon", 0xFFFF4FD8, 0xFF0A0016, 0xFF14002E, 0xFFFF2BD6, 0xFF00E5FF, 0xFF7C4DFF),
        new T("Sunset", 0xFFFF9A6C, 0xFF1A0B2E, 0xFF2B1040, 0xFFFF6B6B, 0xFFFFB86B, 0xFFC147E9),
        new T("Ocean", 0xFF5EA8FF, 0xFF031225, 0xFF06284D, 0xFF1E90FF, 0xFF00C2FF, 0xFF6C63FF),
        new T("Mono", 0xFFE6E6E6, 0xFF0B0B0D, 0xFF18181B, 0xFF52525B, 0xFF71717A, 0xFF3F3F46),
        new T("Forest", 0xFF5BE584, 0xFF04140C, 0xFF0A2A1A, 0xFF10B981, 0xFF84CC16, 0xFF0EA5E9)
    };

    public static T get(int i) { return ALL[Math.max(0, Math.min(ALL.length - 1, i))]; }
}
