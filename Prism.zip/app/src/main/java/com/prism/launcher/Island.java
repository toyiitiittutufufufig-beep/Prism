package com.prism.launcher;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.app.ActivityOptions;
import android.app.Notification;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.service.notification.StatusBarNotification;
import android.view.DisplayCutout;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewOutlineProvider;
import android.view.WindowManager;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.HashMap;
import java.util.Map;

/**
 * A "Dynamic Island": a black pill that sits on the front camera all the time and swells open
 * to show an incoming notification (tap to open it, swipe up to dismiss).
 *
 * It lives in a window above every app. It is attached to the accessibility service when that is on
 * (so it also draws above the status bar), otherwise to the notification service using the
 * "draw over other apps" permission.
 */
public class Island {
    private static Island inst;
    private static final Map<String, Integer> LAST = new HashMap<String, Integer>();

    private final Context host;
    private final int type;
    private final WindowManager wm;
    private final Prefs prefs;
    private final float d;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final GradientDrawable bg = new GradientDrawable();
    private final IslandView view;
    private WindowManager.LayoutParams lp;
    private boolean attached, expanded;
    private int camCx, camTop, camW, camH, screenW, expW, expH;
    private float frac;
    private ValueAnimator anim;
    private PendingIntent tap;
    private String tapPkg = "";
    private final Runnable collapseRun = new Runnable() {
        @Override public void run() { collapse(); }
    };

    // ------------------------------------------------------------ static API

    /** Start, move or stop the island so it matches the settings and the permissions we have. */
    public static synchronized void ensure(Context ctx) {
        Context host = null;
        int type = 0;
        Prefs p = Prefs.get(ctx);
        if (p.b(Prefs.ISLAND, false)) {
            PrismAccessibilityService a = PrismAccessibilityService.get();
            if (a != null) {
                host = a;
                type = WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY;
            } else {
                PrismNotificationService n = PrismNotificationService.get();
                if (n != null && Settings.canDrawOverlays(ctx)) {
                    host = n;
                    type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
                }
            }
        }
        if (host == null) {
            if (inst != null) {
                inst.detach();
                inst = null;
            }
            return;
        }
        if (inst != null && inst.host == host && inst.type == type && inst.attached) {
            inst.relayout();
            return;
        }
        if (inst != null) inst.detach();
        inst = new Island(host, type);
        inst.attach();
    }

    public static void forget(String key) { LAST.remove(key); }

    public static void show(StatusBarNotification s) {
        if (inst != null) inst.showNotification(s);
    }

    /** Settings > Preview. */
    public static void preview(Context ctx) {
        ensure(ctx);
        if (inst != null) {
            Drawable icon = null;
            try { icon = ctx.getPackageManager().getApplicationIcon(ctx.getPackageName()); } catch (Throwable ignored) { }
            inst.display(icon, ctx.getString(R.string.app_name), ctx.getString(R.string.island_preview_text), null, ctx.getPackageName());
        }
    }

    public static String status(Context c) {
        if (inst == null || !inst.attached) return c.getString(R.string.island_off);
        return c.getString(inst.type == WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY ? R.string.island_a11y : R.string.island_overlay);
    }

    // ------------------------------------------------------------ the island

    private Island(Context host, int type) {
        this.host = host;
        this.type = type;
        wm = (WindowManager) host.getSystemService(Context.WINDOW_SERVICE);
        prefs = Prefs.get(host);
        d = host.getResources().getDisplayMetrics().density;
        bg.setColor(0xFF000000);
        view = new IslandView(host);
    }

    private int dp(float v) { return Math.round(v * d); }

    private void attach() {
        computeCamera();
        lp = new WindowManager.LayoutParams(dp(60), dp(30), type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.setTitle("PrismIsland");
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode = Build.VERSION.SDK_INT >= 30
                    ? WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
                    : WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
        applyFrac(0f);
        try {
            wm.addView(view, lp);
            attached = true;
        } catch (Throwable e) {
            attached = false;
        }
        updateVisibility();
    }

    private void detach() {
        h.removeCallbacks(collapseRun);
        if (anim != null) anim.cancel();
        try { wm.removeView(view); } catch (Throwable ignored) { }
        attached = false;
    }

    /** Where the camera hole is. Phones without one get a virtual pill at the top centre. */
    private void computeCamera() {
        screenW = host.getResources().getDisplayMetrics().widthPixels;
        camCx = screenW / 2;
        camTop = dp(8);
        camW = dp(96);
        camH = dp(30);
        if (Build.VERSION.SDK_INT >= 29) {
            try {
                DisplayCutout dc = wm.getDefaultDisplay().getCutout();
                if (dc != null) {
                    for (Rect r : dc.getBoundingRects()) {
                        if (r.top <= dp(3) && r.width() > 0 && r.height() > 0) {
                            camCx = r.centerX();
                            camTop = r.top;
                            camW = r.width();
                            camH = r.height();
                            break;
                        }
                    }
                }
            } catch (Throwable ignored) { }
        }
        expW = Math.min(screenW - dp(24), dp(380));
        expH = dp(76);
    }

    private float scale() { return Math.max(0.6f, prefs.i(Prefs.ISLAND_SCALE, 100) / 100f); }

    private void applyFrac(float f) {
        float s = scale();
        int idleW = Math.round((camW + dp(6)) * s), idleH = Math.round((camH + dp(6)) * s);
        float centerY = camTop + camH / 2f + prefs.i(Prefs.ISLAND_Y, 0) * d;
        float topFixed = centerY - idleH / 2f;
        int w = Math.min(screenW, Math.round(idleW + (expW - idleW) * f));
        int hh = Math.round(idleH + (expH - idleH) * f);
        lp.width = Math.max(1, w);
        lp.height = Math.max(1, hh);
        lp.x = Math.round(camCx + prefs.i(Prefs.ISLAND_X, 0) * d - w / 2f);
        lp.y = Math.round(topFixed);
        bg.setCornerRadius(hh / 2f);
        view.invalidateOutline();
        view.setContentAlpha(Math.max(0f, Math.min(1f, (f - 0.55f) / 0.45f)));
        if (attached) {
            try { wm.updateViewLayout(view, lp); } catch (Throwable ignored) { }
        }
    }

    private void relayout() {
        computeCamera();
        applyFrac(frac);
        updateVisibility();
    }

    private void updateVisibility() {
        boolean landscape = host.getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE;
        boolean show = !landscape && (expanded || frac > 0f || prefs.b(Prefs.ISLAND_IDLE, true));
        view.setVisibility(show ? View.VISIBLE : View.GONE);
    }

    private void setTouchable(boolean t) {
        if (t) lp.flags &= ~WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        else lp.flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        if (attached) {
            try { wm.updateViewLayout(view, lp); } catch (Throwable ignored) { }
        }
    }

    // ------------------------------------------------------------ notifications

    private void showNotification(StatusBarNotification s) {
        if (!attached) return;
        Notification n = s.getNotification();
        Bundle ex = n.extras;
        CharSequence title = ex.getCharSequence(Notification.EXTRA_TITLE);
        CharSequence text = ex.getCharSequence(Notification.EXTRA_TEXT);
        if (text == null) text = ex.getCharSequence(Notification.EXTRA_BIG_TEXT);
        if (title == null && text == null) return;
        int hash = (title + "|" + text).hashCode();
        Integer old = LAST.get(s.getKey());
        if (old != null && old == hash) return;
        LAST.put(s.getKey(), hash);
        Drawable icon = null;
        try { icon = host.getPackageManager().getApplicationIcon(s.getPackageName()); } catch (Throwable ignored) { }
        display(icon, title, text, n.contentIntent, s.getPackageName());
    }

    private void display(Drawable icon, CharSequence title, CharSequence text, PendingIntent pi, String pkg) {
        if (!attached) return;
        tap = pi;
        tapPkg = pkg;
        view.setContent(icon, title, text);
        expand();
    }

    private void expand() {
        if (anim != null) anim.cancel();
        expanded = true;
        setTouchable(true);
        updateVisibility();
        anim = ValueAnimator.ofFloat(frac, 1f);
        anim.setDuration(380);
        anim.setInterpolator(new OvershootInterpolator(0.9f));
        anim.addUpdateListener(a -> {
            frac = (Float) a.getAnimatedValue();
            applyFrac(frac);
        });
        anim.start();
        h.removeCallbacks(collapseRun);
        h.postDelayed(collapseRun, 4500);
    }

    private void collapse() {
        if (!expanded) return;
        expanded = false;
        h.removeCallbacks(collapseRun);
        if (anim != null) anim.cancel();
        anim = ValueAnimator.ofFloat(frac, 0f);
        anim.setDuration(300);
        anim.setInterpolator(new AccelerateDecelerateInterpolator());
        anim.addUpdateListener(a -> {
            frac = (Float) a.getAnimatedValue();
            applyFrac(frac);
        });
        anim.addListener(new AnimatorListenerAdapter() {
            @Override public void onAnimationEnd(Animator a) {
                if (!expanded) {
                    frac = 0f;
                    setTouchable(false);
                    updateVisibility();
                }
            }
        });
        anim.start();
    }

    private void open() {
        collapse();
        try {
            if (tap != null) {
                Bundle opts = null;
                if (Build.VERSION.SDK_INT >= 34) {
                    ActivityOptions ao = ActivityOptions.makeBasic();
                    ao.setPendingIntentBackgroundActivityStartMode(ActivityOptions.MODE_BACKGROUND_ACTIVITY_START_ALLOWED);
                    opts = ao.toBundle();
                }
                tap.send(host, 0, null, null, null, null, opts);
                return;
            }
        } catch (Throwable ignored) { }
        try {
            Intent li = host.getPackageManager().getLaunchIntentForPackage(tapPkg);
            if (li != null) {
                li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                host.startActivity(li);
            }
        } catch (Throwable ignored) { }
    }

    // ------------------------------------------------------------ the view

    private class IslandView extends FrameLayout {
        private final LinearLayout content;
        private final ImageView icon;
        private final TextView title, text;
        private float downY;

        IslandView(Context c) {
            super(c);
            setBackground(bg);
            setOutlineProvider(ViewOutlineProvider.BACKGROUND);
            setClipToOutline(true);

            content = new LinearLayout(c);
            content.setGravity(Gravity.CENTER_VERTICAL);
            content.setPadding(dp(18), 0, dp(22), 0);
            icon = new ImageView(c);
            Util.round(icon, dp(11));
            LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(dp(42), dp(42));
            content.addView(icon, ip);
            LinearLayout col = new LinearLayout(c);
            col.setOrientation(LinearLayout.VERTICAL);
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(0, -2, 1f);
            cp.leftMargin = dp(14);
            title = new TextView(c);
            title.setTextColor(0xFFFFFFFF);
            title.setTextSize(15);
            title.setTypeface(Typeface.DEFAULT_BOLD);
            title.setSingleLine(true);
            title.setEllipsize(android.text.TextUtils.TruncateAt.END);
            text = new TextView(c);
            text.setTextColor(0xB3FFFFFF);
            text.setTextSize(13);
            text.setSingleLine(true);
            text.setEllipsize(android.text.TextUtils.TruncateAt.END);
            col.addView(title);
            col.addView(text);
            content.addView(col, cp);
            content.setAlpha(0f);
            // always laid out at the full expanded size, the rounded window just reveals more of it
            addView(content, new FrameLayout.LayoutParams(expW > 0 ? expW : dp(360), expH > 0 ? expH : dp(76), Gravity.CENTER));
        }

        void setContent(Drawable ic, CharSequence t, CharSequence x) {
            icon.setImageDrawable(ic);
            title.setText(t == null ? "" : t);
            title.setVisibility(t == null || t.length() == 0 ? GONE : VISIBLE);
            text.setText(x == null ? "" : x);
            text.setVisibility(x == null || x.length() == 0 ? GONE : VISIBLE);
            FrameLayout.LayoutParams p = (FrameLayout.LayoutParams) content.getLayoutParams();
            p.width = expW;
            p.height = expH;
            content.setLayoutParams(p);
        }

        void setContentAlpha(float a) { content.setAlpha(a); }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    downY = e.getRawY();
                    h.removeCallbacks(collapseRun);
                    return true;
                case MotionEvent.ACTION_UP: {
                    float dy = e.getRawY() - downY;
                    if (dy < -dp(18)) collapse();
                    else if (Math.abs(dy) < dp(14)) open();
                    else h.postDelayed(collapseRun, 2500);
                    return true;
                }
                case MotionEvent.ACTION_CANCEL:
                    h.postDelayed(collapseRun, 2500);
                    return true;
            }
            return true;
        }

        @Override
        protected void onConfigurationChanged(Configuration c) {
            super.onConfigurationChanged(c);
            relayout();
        }
    }
}
