package com.prism.launcher;

import android.content.ComponentName;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/** One thing on the home screen: an app icon, a folder, a widget, the clock card or the search bar. */
public class ItemInfo {
    public static final int APP = 0, WIDGET = 1, CLOCK = 2, FOLDER = 3, SEARCH = 4;

    public long id;
    public int type;
    public String comp = "";
    public int widgetId = -1;
    public int page, cx, cy, sx = 1, sy = 1;
    public boolean dock;
    public String title = "";
    public List<String> apps = new ArrayList<String>();

    public ComponentName component() {
        return comp.length() == 0 ? null : ComponentName.unflattenFromString(comp);
    }

    public JSONObject toJson() throws JSONException {
        JSONObject o = new JSONObject();
        o.put("id", id).put("t", type).put("c", comp).put("w", widgetId)
                .put("p", page).put("x", cx).put("y", cy).put("sx", sx).put("sy", sy).put("d", dock)
                .put("ti", title).put("ap", new JSONArray(apps));
        return o;
    }

    public static ItemInfo fromJson(JSONObject o) {
        ItemInfo i = new ItemInfo();
        i.id = o.optLong("id");
        i.type = o.optInt("t");
        i.comp = o.optString("c", "");
        i.widgetId = o.optInt("w", -1);
        i.page = o.optInt("p");
        i.cx = o.optInt("x");
        i.cy = o.optInt("y");
        i.sx = Math.max(1, o.optInt("sx", 1));
        i.sy = Math.max(1, o.optInt("sy", 1));
        i.dock = o.optBoolean("d");
        i.title = o.optString("ti", "");
        JSONArray a = o.optJSONArray("ap");
        if (a != null) for (int k = 0; k < a.length(); k++) i.apps.add(a.optString(k));
        return i;
    }
}
