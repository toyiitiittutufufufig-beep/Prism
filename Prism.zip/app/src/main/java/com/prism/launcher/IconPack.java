package com.prism.launcher;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.drawable.Drawable;
import android.util.Xml;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.xmlpull.v1.XmlPullParser;

/** Supports the common ADW / Nova / Apex icon packs (they all ship an appfilter.xml). */
public class IconPack {
    private static final String[] ACTIONS = {"org.adw.launcher.THEMES", "com.novalauncher.THEME", "com.anddoes.launcher.THEME"};

    public final String pkg;
    private Resources res;
    private final Map<String, String> map = new HashMap<String, String>();
    private final List<String> backs = new ArrayList<String>();
    private String mask, upon;
    private float scale = 1f;

    private IconPack(String pkg) { this.pkg = pkg; }

    /** {package, label} of every installed pack. */
    public static List<String[]> installed(Context c) {
        PackageManager pm = c.getPackageManager();
        Map<String, String[]> out = new LinkedHashMap<String, String[]>();
        for (String act : ACTIONS) {
            try {
                for (ResolveInfo ri : pm.queryIntentActivities(new Intent(act), 0)) {
                    String p = ri.activityInfo.packageName;
                    if (!out.containsKey(p)) out.put(p, new String[] {p, String.valueOf(ri.loadLabel(pm))});
                }
            } catch (Throwable ignored) { }
        }
        return new ArrayList<String[]>(out.values());
    }

    public static IconPack load(Context c, String pkg) {
        IconPack ip = new IconPack(pkg);
        try {
            ip.res = c.getPackageManager().getResourcesForApplication(pkg);
            ip.parse();
            return ip;
        } catch (Throwable e) {
            return null;
        }
    }

    private void parse() throws Exception {
        XmlPullParser x = null;
        int id = res.getIdentifier("appfilter", "xml", pkg);
        if (id != 0) {
            x = res.getXml(id);
        } else {
            InputStream in = res.getAssets().open("appfilter.xml");
            x = Xml.newPullParser();
            x.setInput(in, "utf-8");
        }
        int ev = x.getEventType();
        while (ev != XmlPullParser.END_DOCUMENT) {
            if (ev == XmlPullParser.START_TAG) {
                String n = x.getName();
                if ("item".equals(n)) {
                    String comp = x.getAttributeValue(null, "component");
                    String dr = x.getAttributeValue(null, "drawable");
                    if (comp != null && dr != null && comp.startsWith("ComponentInfo{") && comp.endsWith("}")) {
                        String inner = comp.substring(14, comp.length() - 1);
                        int slash = inner.indexOf('/');
                        if (slash > 0) {
                            String p = inner.substring(0, slash), cl = inner.substring(slash + 1);
                            if (cl.startsWith(".")) cl = p + cl;
                            map.put(p + "/" + cl, dr);
                        }
                    }
                } else if ("iconback".equals(n)) {
                    for (int i = 0; i < x.getAttributeCount(); i++) {
                        if (x.getAttributeName(i).startsWith("img")) backs.add(x.getAttributeValue(i));
                    }
                } else if ("iconmask".equals(n)) {
                    if (x.getAttributeCount() > 0) mask = x.getAttributeValue(0);
                } else if ("iconupon".equals(n)) {
                    if (x.getAttributeCount() > 0) upon = x.getAttributeValue(0);
                } else if ("scale".equals(n)) {
                    String f = x.getAttributeValue(null, "factor");
                    if (f != null) scale = Float.parseFloat(f);
                }
            }
            ev = x.next();
        }
    }

    private Drawable byName(String name) {
        if (name == null) return null;
        try {
            int id = res.getIdentifier(name, "drawable", pkg);
            if (id == 0) return null;
            return res.getDrawable(id, null);
        } catch (Throwable e) {
            return null;
        }
    }

    public Drawable get(ComponentName cn) {
        String n = map.get(cn.getPackageName() + "/" + cn.getClassName());
        return byName(n);
    }

    public boolean hasBack() { return !backs.isEmpty(); }

    /** Apps the pack doesn't cover: the original icon sits on the pack's background, under its mask. */
    public Bitmap compose(Drawable orig, int px) {
        Bitmap out = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(out);
        Drawable back = byName(backs.get(Math.abs(px) % backs.size()));
        if (back != null) {
            back.setBounds(0, 0, px, px);
            back.draw(c);
        }
        int in = Math.round(px * scale * 0.7f);
        int off = (px - in) / 2;
        orig.setBounds(off, off, off + in, off + in);
        orig.draw(c);
        Drawable m = byName(mask);
        if (m != null) {
            Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            p.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_OUT));
            Bitmap mb = Util.toBitmap(m, px, px);
            c.drawBitmap(mb, 0, 0, p);
        }
        Drawable u = byName(upon);
        if (u != null) {
            u.setBounds(0, 0, px, px);
            u.draw(c);
        }
        return out;
    }
}
