PRISM LAUNCHER - glass home screen
==================================
Build: push this folder (or the zip) to GitHub -> Actions -> "Build APK" -> download Prism-APK.
Install it, open "Prism", tap "Make Prism your home screen", press Home.

Home: pages, 1x1 icons, widgets (resizable), glass clock card, glass dock, drag & drop,
      drag to the top strip to Remove / App info / Uninstall, drag to a screen edge to change page.
Drawer: swipe up from anywhere. Blurred glass, instant search (names, initials, package), Enter launches the first result,
      A-Z scroller, long-press for app shortcuts / add to home / hide / uninstall.
Gestures: swipe down, double tap, two fingers up, two fingers down -> configurable (notifications, quick settings,
      lock screen*, recents*, search, flashlight, edit, any app).   *needs the Prism accessibility service.
Look: 6 themes, icon shapes, glass tiles, icon size, labels, ADW/Nova/Apex icon packs, grid size.
Wallpaper: animated Aurora / Waves / Bokeh / Stars / Gradient, your own photo, system wallpaper,
      or set Prism as a real live wallpaper.

NEW in this version
- Folders: drop an icon on another icon (home or dock) to make a folder, on a folder to add to it.
  Tap to open, tap the title to rename, long-press an app inside to move it out.
- Notification badges on icons and folders (dots or numbers). Settings > Badges > Notification access.
- Search bar item (edit sheet > Search bar): tap it to search all apps.
- Lock layout (edit sheet or settings): no more accidental moves.
- Rename any app (long-press > Rename); the new name is searched too.
- Drawer sort: A-Z, Most used, Recently used.
- Hide status bar, dim background slider.
- Backup / restore layout + settings to a file.

ALSO ADDED
- Work profile apps (with the briefcase badge), launched in the right profile.
- "Suggested" row in the drawer (your most-launched apps).
- Calculator in the drawer search ("12*(3+4)" -> tap to copy).
- Themed icons (Android 13+): the app's one-color icon in your theme color.
- Optional rotation (landscape), glass-or-clear dock, reset home screen.

DYNAMIC ISLAND
Settings > Dynamic Island: turn it on. A black pill sits on the front camera; incoming notifications swell out of it
(tap = open the notification, swipe up = dismiss). Needs: Notification access + (Accessibility OR "draw over other apps").
Accessibility is better: the island then also draws above the status bar. Use the sliders to line it up with the camera.
